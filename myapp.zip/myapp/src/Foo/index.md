---
nav:
  title: Components
  path: /components
---

## Foo

Demo:

```tsx
import React from 'react';
import { Foo } from 'myapp';

export default () => <Foo title="First Demo" />;
```

More skills for writing demo: https://d.umijs.org/guide/demo-principle
