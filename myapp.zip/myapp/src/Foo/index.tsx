import React from 'react';

export default ({ title }: { title: string }) => <h1>{title}</h1>;
