export { default as Foo } from './Foo';
