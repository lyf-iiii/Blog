// @ts-nocheck
import React from 'react';
import { dynamic } from 'dumi';

export default {
  'Foo-demo': {
    component: function DumiDemo() {
  var _interopRequireDefault = require("/Users/lianyafeng/Desktop/\u5B66\u4E60demo/dumi/myapp/node_modules/@babel/runtime/helpers/interopRequireDefault");

  var _react = _interopRequireDefault(require("react"));

  var _myapp = require("myapp");

  var _default = function _default() {
    return /*#__PURE__*/_react["default"].createElement(_myapp.Foo, {
      title: "First Demo"
    });
  };

  return _react["default"].createElement(_default);
},
    previewerProps: {"sources":{"_":{"tsx":"import React from 'react';\nimport { Foo } from 'myapp';\n\nexport default () => <Foo title=\"First Demo\" />;"}},"dependencies":{"react":{"version":"16.14.0"},"myapp":{"version":"1.0.0"}},"componentName":"Foo","identifier":"Foo-demo"},
  },
};
