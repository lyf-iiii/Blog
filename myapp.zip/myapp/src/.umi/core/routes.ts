// @ts-nocheck
import React from 'react';
import { ApplyPluginsType } from '/Users/lianyafeng/Desktop/学习demo/dumi/myapp/node_modules/@umijs/runtime';
import * as umiExports from './umiExports';
import { plugin } from './plugin';

export function getRoutes() {
  const routes = [
  {
    "path": "/~demos/:uuid",
    "layout": false,
    "wrappers": [require('/Users/lianyafeng/Desktop/学习demo/dumi/myapp/node_modules/@umijs/preset-dumi/lib/theme/layout').default],
    "component": (props) => {
        const { default: getDemoRenderArgs } = require('/Users/lianyafeng/Desktop/学习demo/dumi/myapp/node_modules/@umijs/preset-dumi/lib/plugins/features/demo/getDemoRenderArgs');
        const { default: Previewer } = require('dumi-theme-default/src/builtins/Previewer.tsx');
        const { default: demos } = require('@@/dumi/demos');
        const { usePrefersColor } = require('dumi/theme');

        
      const renderArgs = getDemoRenderArgs(props, demos);

      // for listen prefers-color-schema media change in demo single route
      usePrefersColor();

      switch (renderArgs.length) {
        case 1:
          // render demo directly
          return renderArgs[0];

        case 2:
          // render demo with previewer
          return React.createElement(
            Previewer,
            renderArgs[0],
            renderArgs[1],
          );

        default:
          return `Demo ${props.match.params.uuid} not found :(`;
      }
    
        }
  },
  {
    "path": "/_demos/:uuid",
    "redirect": "/~demos/:uuid"
  },
  {
    "__dumiRoot": true,
    "layout": false,
    "path": "/",
    "wrappers": [require('/Users/lianyafeng/Desktop/学习demo/dumi/myapp/node_modules/@umijs/preset-dumi/lib/theme/layout').default, require('/Users/lianyafeng/Desktop/学习demo/dumi/myapp/node_modules/dumi-theme-default/src/layout.tsx').default],
    "routes": [
      {
        "path": "/css",
        "component": require('/Users/lianyafeng/Desktop/学习demo/dumi/myapp/src/css.md').default,
        "exact": true,
        "meta": {
          "filePath": "src/css.md",
          "updatedTime": 1627059170883,
          "slugs": [
            {
              "depth": 1,
              "value": "CSS",
              "heading": "css"
            },
            {
              "depth": 2,
              "value": "清除浮动",
              "heading": "清除浮动"
            },
            {
              "depth": 2,
              "value": "盒模型",
              "heading": "盒模型"
            },
            {
              "depth": 2,
              "value": "transition 和animation的区别",
              "heading": "transition-和animation的区别"
            },
            {
              "depth": 2,
              "value": "BFC",
              "heading": "bfc"
            },
            {
              "depth": 3,
              "value": "BFC的理解",
              "heading": "bfc的理解"
            },
            {
              "depth": 3,
              "value": "规则",
              "heading": "规则"
            },
            {
              "depth": 3,
              "value": "BFC中的盒子对齐",
              "heading": "bfc中的盒子对齐"
            },
            {
              "depth": 3,
              "value": "外边距重叠",
              "heading": "外边距重叠"
            },
            {
              "depth": 2,
              "value": "Flex",
              "heading": "flex"
            },
            {
              "depth": 2,
              "value": "解决css阻塞污染的问题",
              "heading": "解决css阻塞污染的问题"
            },
            {
              "depth": 2,
              "value": "css 的缩放、渐变、旋转和平移",
              "heading": "css-的缩放、渐变、旋转和平移"
            },
            {
              "depth": 2,
              "value": "三栏布局 的5种方案",
              "heading": "三栏布局-的5种方案"
            },
            {
              "depth": 2,
              "value": "圣杯布局 的三种方案",
              "heading": "圣杯布局-的三种方案"
            },
            {
              "depth": 2,
              "value": "吸顶布局",
              "heading": "吸顶布局"
            }
          ],
          "title": "CSS",
          "nav": {
            "path": "/css",
            "title": "Css"
          }
        },
        "title": "CSS"
      },
      {
        "path": "/functional-javascript",
        "component": require('/Users/lianyafeng/Desktop/学习demo/dumi/myapp/src/functional-javascript.md').default,
        "exact": true,
        "meta": {
          "filePath": "src/functional-javascript.md",
          "updatedTime": 1626156067289,
          "slugs": [
            {
              "depth": 2,
              "value": "Hello world",
              "heading": "hello-world"
            },
            {
              "depth": 2,
              "value": "Higher Order Functions",
              "heading": "higher-order-functions"
            },
            {
              "depth": 2,
              "value": "map",
              "heading": "map"
            },
            {
              "depth": 2,
              "value": "Filter",
              "heading": "filter"
            },
            {
              "depth": 2,
              "value": "Basic: Every Some",
              "heading": "basic-every-some"
            },
            {
              "depth": 2,
              "value": "reduce",
              "heading": "reduce"
            },
            {
              "depth": 2,
              "value": "Basic：Recursion",
              "heading": "basic：recursion"
            },
            {
              "depth": 2,
              "value": "Basic: Call",
              "heading": "basic-call"
            },
            {
              "depth": 2,
              "value": "Partial Application without Bind",
              "heading": "partial-application-without-bind"
            },
            {
              "depth": 2,
              "value": "Partial Application with Bind",
              "heading": "partial-application-with-bind"
            },
            {
              "depth": 2,
              "value": "Implement Map with Reduce",
              "heading": "implement-map-with-reduce"
            },
            {
              "depth": 2,
              "value": "Function Spies",
              "heading": "function-spies"
            },
            {
              "depth": 2,
              "value": "Blocking Event Loop",
              "heading": "blocking-event-loop"
            },
            {
              "depth": 2,
              "value": "Trampoline",
              "heading": "trampoline"
            },
            {
              "depth": 2,
              "value": "Async Loops",
              "heading": "async-loops"
            },
            {
              "depth": 2,
              "value": "Recursion",
              "heading": "recursion"
            },
            {
              "depth": 2,
              "value": "Currying",
              "heading": "currying"
            },
            {
              "depth": 2,
              "value": "Function Call",
              "heading": "function-call"
            }
          ],
          "title": "Hello world",
          "nav": {
            "path": "/functional-javascript",
            "title": "Functional-javascript"
          }
        },
        "title": "Hello world"
      },
      {
        "path": "/",
        "component": require('/Users/lianyafeng/Desktop/学习demo/dumi/myapp/src/index.md').default,
        "exact": true,
        "meta": {
          "filePath": "src/index.md",
          "updatedTime": 1621143722304,
          "slugs": [
            {
              "depth": 1,
              "value": "Hello dumi1!",
              "heading": "hello-dumi1"
            }
          ],
          "title": "Hello dumi1!"
        },
        "title": "Hello dumi1!"
      },
      {
        "path": "/js",
        "component": require('/Users/lianyafeng/Desktop/学习demo/dumi/myapp/src/js.md').default,
        "exact": true,
        "meta": {
          "filePath": "src/js.md",
          "updatedTime": 1627130278339,
          "slugs": [
            {
              "depth": 2,
              "value": "拖拽",
              "heading": "拖拽"
            },
            {
              "depth": 2,
              "value": "原型/构造函数/实例",
              "heading": "原型构造函数实例"
            },
            {
              "depth": 2,
              "value": "原型链",
              "heading": "原型链"
            },
            {
              "depth": 2,
              "value": "JS 执行上下文",
              "heading": "js-执行上下文"
            },
            {
              "depth": 3,
              "value": "全局执行上下文",
              "heading": "全局执行上下文"
            },
            {
              "depth": 3,
              "value": "函数执行上下文",
              "heading": "函数执行上下文"
            },
            {
              "depth": 2,
              "value": "闭包",
              "heading": "闭包"
            },
            {
              "depth": 2,
              "value": "对象的拷贝",
              "heading": "对象的拷贝"
            },
            {
              "depth": 2,
              "value": "new 运算符的执行过程",
              "heading": "new-运算符的执行过程"
            },
            {
              "depth": 2,
              "value": "instanceof 原理",
              "heading": "instanceof-原理"
            },
            {
              "depth": 2,
              "value": "类型判断",
              "heading": "类型判断"
            },
            {
              "depth": 2,
              "value": "模块化",
              "heading": "模块化"
            },
            {
              "depth": 2,
              "value": "防抖与节流",
              "heading": "防抖与节流"
            },
            {
              "depth": 2,
              "value": "js的由来 以及单线程的原因",
              "heading": "js的由来-以及单线程的原因"
            },
            {
              "depth": 2,
              "value": "AST 抽象语法树",
              "heading": "ast-抽象语法树"
            },
            {
              "depth": 2,
              "value": "js代码的执行过程",
              "heading": "js代码的执行过程"
            },
            {
              "depth": 2,
              "value": "babel 编译原理",
              "heading": "babel-编译原理"
            },
            {
              "depth": 2,
              "value": "v8引擎运行的三个阶段",
              "heading": "v8引擎运行的三个阶段"
            },
            {
              "depth": 2,
              "value": "函数柯里化",
              "heading": "函数柯里化"
            },
            {
              "depth": 2,
              "value": "跨域",
              "heading": "跨域"
            },
            {
              "depth": 2,
              "value": "Event loop 中的 job queue",
              "heading": "event-loop-中的-job-queue"
            },
            {
              "depth": 2,
              "value": "更复杂的例子",
              "heading": "更复杂的例子"
            },
            {
              "depth": 2,
              "value": "实现 sleep 的效果",
              "heading": "实现-sleep-的效果"
            },
            {
              "depth": 3,
              "value": "通过 promise 的方式来实现",
              "heading": "通过-promise-的方式来实现"
            },
            {
              "depth": 2,
              "value": "Promise",
              "heading": "promise"
            },
            {
              "depth": 4,
              "value": "手写一个 promise",
              "heading": "手写一个-promise"
            },
            {
              "depth": 2,
              "value": "promise 的应用场景",
              "heading": "promise-的应用场景"
            },
            {
              "depth": 2,
              "value": "js 数组的方法",
              "heading": "js-数组的方法"
            },
            {
              "depth": 2,
              "value": "字符串的方法",
              "heading": "字符串的方法"
            },
            {
              "depth": 2,
              "value": "es6 新特性",
              "heading": "es6-新特性"
            },
            {
              "depth": 2,
              "value": "this",
              "heading": "this"
            },
            {
              "depth": 2,
              "value": "数组扁平化",
              "heading": "数组扁平化"
            },
            {
              "depth": 2,
              "value": "dom 的 api",
              "heading": "dom-的-api"
            },
            {
              "depth": 2,
              "value": "virtual dom",
              "heading": "virtual-dom"
            },
            {
              "depth": 2,
              "value": "function 可以 new 那么箭头函数可以吗",
              "heading": "function-可以-new-那么箭头函数可以吗"
            },
            {
              "depth": 2,
              "value": "JavaScript对象的底层数据结构是什么",
              "heading": "javascript对象的底层数据结构是什么"
            },
            {
              "depth": 2,
              "value": "基本类型对应的内置对象，以及他们之间的装箱拆箱操作",
              "heading": "基本类型对应的内置对象，以及他们之间的装箱拆箱操作"
            },
            {
              "depth": 2,
              "value": "null和undefined的区别",
              "heading": "null和undefined的区别"
            },
            {
              "depth": 2,
              "value": "判断数据类型的几种方法",
              "heading": "判断数据类型的几种方法"
            },
            {
              "depth": 2,
              "value": "es6 class的底层实现",
              "heading": "es6-class的底层实现"
            },
            {
              "depth": 2,
              "value": "理解词法作用域和动态作用域",
              "heading": "理解词法作用域和动态作用域"
            },
            {
              "depth": 2,
              "value": "理解堆栈溢出和内存泄漏的原理，如何防止",
              "heading": "理解堆栈溢出和内存泄漏的原理，如何防止"
            },
            {
              "depth": 2,
              "value": "如何处理循环的异步操作",
              "heading": "如何处理循环的异步操作"
            },
            {
              "depth": 2,
              "value": "理解模块化解决的实际问题，可列举几个模块化方案并理解其中原理",
              "heading": "理解模块化解决的实际问题，可列举几个模块化方案并理解其中原理"
            },
            {
              "depth": 2,
              "value": "为何try里面放return，finally还会执行，理解其内部机制",
              "heading": "为何try里面放return，finally还会执行，理解其内部机制"
            },
            {
              "depth": 2,
              "value": "Promise 并行和串行理解",
              "heading": "promise-并行和串行理解"
            },
            {
              "depth": 2,
              "value": "什么是高阶函数",
              "heading": "什么是高阶函数"
            },
            {
              "depth": 2,
              "value": "将伪数组转化为数组",
              "heading": "将伪数组转化为数组"
            }
          ],
          "title": "拖拽",
          "nav": {
            "path": "/js",
            "title": "Js"
          }
        },
        "title": "拖拽"
      },
      {
        "path": "/node",
        "component": require('/Users/lianyafeng/Desktop/学习demo/dumi/myapp/src/node.md').default,
        "exact": true,
        "meta": {
          "filePath": "src/node.md",
          "updatedTime": 1624891891531,
          "slugs": [
            {
              "depth": 1,
              "value": "nodeJS学习",
              "heading": "nodejs学习"
            },
            {
              "depth": 2,
              "value": "node事件循环 event loop",
              "heading": "node事件循环-event-loop"
            },
            {
              "depth": 3,
              "value": "什么是事件循环",
              "heading": "什么是事件循环"
            },
            {
              "depth": 3,
              "value": "工作原理",
              "heading": "工作原理"
            },
            {
              "depth": 4,
              "value": "定义事件队列",
              "heading": "定义事件队列"
            },
            {
              "depth": 4,
              "value": "定义接受请求入口",
              "heading": "定义接受请求入口"
            },
            {
              "depth": 4,
              "value": "定义 Event loop",
              "heading": "定义-event-loop"
            },
            {
              "depth": 4,
              "value": "处理 I/O 任务",
              "heading": "处理-io-任务"
            },
            {
              "depth": 3,
              "value": "nodejs 的短板",
              "heading": "nodejs-的短板"
            },
            {
              "depth": 3,
              "value": "node的适用场景",
              "heading": "node的适用场景"
            },
            {
              "depth": 2,
              "value": "node的特征",
              "heading": "node的特征"
            },
            {
              "depth": 2,
              "value": "node解决跨域问题",
              "heading": "node解决跨域问题"
            },
            {
              "depth": 2,
              "value": "node 全局对象",
              "heading": "node-全局对象"
            },
            {
              "depth": 2,
              "value": "node process",
              "heading": "node-process"
            },
            {
              "depth": 2,
              "value": "node fs",
              "heading": "node-fs"
            },
            {
              "depth": 2,
              "value": "Buffer",
              "heading": "buffer"
            },
            {
              "depth": 2,
              "value": "react-travel",
              "heading": "react-travel"
            },
            {
              "depth": 3,
              "value": "技术栈",
              "heading": "技术栈"
            },
            {
              "depth": 3,
              "value": "模块",
              "heading": "模块"
            },
            {
              "depth": 3,
              "value": "koa、koa2、express",
              "heading": "koa、koa2、express"
            }
          ],
          "title": "nodeJS学习",
          "nav": {
            "path": "/node",
            "title": "Node"
          }
        },
        "title": "nodeJS学习"
      },
      {
        "path": "/react",
        "component": require('/Users/lianyafeng/Desktop/学习demo/dumi/myapp/src/react.md').default,
        "exact": true,
        "meta": {
          "filePath": "src/react.md",
          "updatedTime": 1625648941818,
          "slugs": [
            {
              "depth": 1,
              "value": "react",
              "heading": "react"
            },
            {
              "depth": 2,
              "value": "react 是什么",
              "heading": "react-是什么"
            },
            {
              "depth": 2,
              "value": "react 的特点",
              "heading": "react-的特点"
            },
            {
              "depth": 2,
              "value": "安装",
              "heading": "安装"
            },
            {
              "depth": 2,
              "value": "使用",
              "heading": "使用"
            },
            {
              "depth": 2,
              "value": "脚手架create-react-app",
              "heading": "脚手架create-react-app"
            },
            {
              "depth": 2,
              "value": "npx",
              "heading": "npx"
            },
            {
              "depth": 2,
              "value": "jsx",
              "heading": "jsx"
            },
            {
              "depth": 2,
              "value": "组件",
              "heading": "组件"
            },
            {
              "depth": 3,
              "value": "函数组件",
              "heading": "函数组件"
            },
            {
              "depth": 3,
              "value": "类组件",
              "heading": "类组件"
            },
            {
              "depth": 2,
              "value": "复合组件",
              "heading": "复合组件"
            },
            {
              "depth": 2,
              "value": "State 状态",
              "heading": "state-状态"
            },
            {
              "depth": 2,
              "value": "props",
              "heading": "props"
            },
            {
              "depth": 2,
              "value": "props 验证",
              "heading": "props-验证"
            },
            {
              "depth": 2,
              "value": "事件处理",
              "heading": "事件处理"
            },
            {
              "depth": 2,
              "value": "条件渲染",
              "heading": "条件渲染"
            },
            {
              "depth": 2,
              "value": "列表渲染",
              "heading": "列表渲染"
            },
            {
              "depth": 2,
              "value": "react 组件 api",
              "heading": "react-组件-api"
            },
            {
              "depth": 2,
              "value": "react 的生命周期",
              "heading": "react-的生命周期"
            },
            {
              "depth": 2,
              "value": "表单处理",
              "heading": "表单处理"
            },
            {
              "depth": 3,
              "value": "受控组件",
              "heading": "受控组件"
            },
            {
              "depth": 3,
              "value": "非受控组件",
              "heading": "非受控组件"
            },
            {
              "depth": 3,
              "value": "组件评论练习",
              "heading": "组件评论练习"
            },
            {
              "depth": 2,
              "value": "props 接收数据",
              "heading": "props-接收数据"
            },
            {
              "depth": 3,
              "value": "props children 属性",
              "heading": "props-children-属性"
            },
            {
              "depth": 2,
              "value": "父子组件之间的通讯",
              "heading": "父子组件之间的通讯"
            },
            {
              "depth": 2,
              "value": "兄弟组件之间的通讯",
              "heading": "兄弟组件之间的通讯"
            },
            {
              "depth": 2,
              "value": "组件添加 props 校验",
              "heading": "组件添加-props-校验"
            },
            {
              "depth": 2,
              "value": "生命周期常用的钩子函数",
              "heading": "生命周期常用的钩子函数"
            },
            {
              "depth": 3,
              "value": "1.创建时",
              "heading": "1创建时"
            },
            {
              "depth": 3,
              "value": "2.更新时",
              "heading": "2更新时"
            },
            {
              "depth": 3,
              "value": "3.卸载时",
              "heading": "3卸载时"
            },
            {
              "depth": 2,
              "value": "高阶组件的作用",
              "heading": "高阶组件的作用"
            },
            {
              "depth": 3,
              "value": "render props 模式",
              "heading": "render-props-模式"
            },
            {
              "depth": 3,
              "value": "高阶组件",
              "heading": "高阶组件"
            },
            {
              "depth": 2,
              "value": "setState 更新数据是异步的",
              "heading": "setstate-更新数据是异步的"
            },
            {
              "depth": 3,
              "value": "setState 推荐语法",
              "heading": "setstate-推荐语法"
            },
            {
              "depth": 2,
              "value": "jsx 语法的转化过程",
              "heading": "jsx-语法的转化过程"
            },
            {
              "depth": 2,
              "value": "React 组件的更新机制",
              "heading": "react-组件的更新机制"
            },
            {
              "depth": 2,
              "value": "对组件进行性能优化",
              "heading": "对组件进行性能优化"
            },
            {
              "depth": 2,
              "value": "虚拟 DOM 和 Diff 算法",
              "heading": "虚拟-dom-和-diff-算法"
            },
            {
              "depth": 3,
              "value": "diff 算法 实质是找不同",
              "heading": "diff-算法-实质是找不同"
            },
            {
              "depth": 2,
              "value": "纯组件 PureComponent",
              "heading": "纯组件-purecomponent"
            },
            {
              "depth": 2,
              "value": "react-router-dom",
              "heading": "react-router-dom"
            },
            {
              "depth": 2,
              "value": "路由的执行过程",
              "heading": "路由的执行过程"
            },
            {
              "depth": 2,
              "value": "编程式导航",
              "heading": "编程式导航"
            },
            {
              "depth": 2,
              "value": "默认路由 进入页面时就会匹配的路由",
              "heading": "默认路由-进入页面时就会匹配的路由"
            },
            {
              "depth": 3,
              "value": "模糊匹配模式",
              "heading": "模糊匹配模式"
            },
            {
              "depth": 3,
              "value": "精确匹配",
              "heading": "精确匹配"
            },
            {
              "depth": 2,
              "value": "hooks",
              "heading": "hooks"
            },
            {
              "depth": 2,
              "value": "纯函数",
              "heading": "纯函数"
            },
            {
              "depth": 2,
              "value": "redux 数据仓库",
              "heading": "redux-数据仓库"
            },
            {
              "depth": 2,
              "value": "旅游网站业务",
              "heading": "旅游网站业务"
            },
            {
              "depth": 2,
              "value": "redux redux-toolkit",
              "heading": "redux-redux-toolkit"
            },
            {
              "depth": 2,
              "value": "redux-persist 登陆持久化",
              "heading": "redux-persist-登陆持久化"
            },
            {
              "depth": 2,
              "value": "发布流程",
              "heading": "发布流程"
            },
            {
              "depth": 2,
              "value": "docker",
              "heading": "docker"
            },
            {
              "depth": 2,
              "value": "docker的三个核心概念",
              "heading": "docker的三个核心概念"
            }
          ],
          "title": "react",
          "nav": {
            "path": "/react",
            "title": "React"
          }
        },
        "title": "react"
      },
      {
        "path": "/three",
        "component": require('/Users/lianyafeng/Desktop/学习demo/dumi/myapp/src/three.md').default,
        "exact": true,
        "meta": {
          "filePath": "src/three.md",
          "updatedTime": 1623206712854,
          "slugs": [
            {
              "depth": 1,
              "value": "three",
              "heading": "three"
            },
            {
              "depth": 2,
              "value": "创建一个场景",
              "heading": "创建一个场景"
            },
            {
              "depth": 2,
              "value": "在 threejs 中定义一个点",
              "heading": "在-threejs-中定义一个点"
            },
            {
              "depth": 2,
              "value": "绘制一个坐标系",
              "heading": "绘制一个坐标系"
            },
            {
              "depth": 2,
              "value": "性能监视器 Stats",
              "heading": "性能监视器-stats"
            },
            {
              "depth": 2,
              "value": "动画引擎 Tween",
              "heading": "动画引擎-tween"
            },
            {
              "depth": 2,
              "value": "光源 Light",
              "heading": "光源-light"
            },
            {
              "depth": 3,
              "value": "光源基类",
              "heading": "光源基类"
            },
            {
              "depth": 3,
              "value": "派生光源",
              "heading": "派生光源"
            }
          ],
          "title": "three",
          "nav": {
            "path": "/three",
            "title": "Three"
          }
        },
        "title": "three"
      },
      {
        "path": "/ts",
        "component": require('/Users/lianyafeng/Desktop/学习demo/dumi/myapp/src/ts.md').default,
        "exact": true,
        "meta": {
          "filePath": "src/ts.md",
          "updatedTime": 1627101538394,
          "slugs": [
            {
              "depth": 1,
              "value": "TypeScript",
              "heading": "typescript"
            },
            {
              "depth": 2,
              "value": "什么是TyprScript",
              "heading": "什么是typrscript"
            },
            {
              "depth": 2,
              "value": "tsc 命令",
              "heading": "tsc-命令"
            },
            {
              "depth": 2,
              "value": "类型批注",
              "heading": "类型批注"
            },
            {
              "depth": 2,
              "value": "interface",
              "heading": "interface"
            },
            {
              "depth": 2,
              "value": "lambda函数表达式",
              "heading": "lambda函数表达式"
            },
            {
              "depth": 2,
              "value": "class类",
              "heading": "class类"
            },
            {
              "depth": 2,
              "value": "继承",
              "heading": "继承"
            },
            {
              "depth": 2,
              "value": "any 类型",
              "heading": "any-类型"
            },
            {
              "depth": 2,
              "value": "null undefined",
              "heading": "null-undefined"
            },
            {
              "depth": 2,
              "value": "naver 类型",
              "heading": "naver-类型"
            },
            {
              "depth": 2,
              "value": "变量声明",
              "heading": "变量声明"
            },
            {
              "depth": 2,
              "value": "类型推断",
              "heading": "类型推断"
            },
            {
              "depth": 2,
              "value": "变量作用域",
              "heading": "变量作用域"
            },
            {
              "depth": 2,
              "value": "tsconfig.json 的作用",
              "heading": "tsconfigjson-的作用"
            },
            {
              "depth": 2,
              "value": "如何配置typescript编译器",
              "heading": "如何配置typescript编译器"
            }
          ],
          "title": "TypeScript",
          "nav": {
            "path": "/ts",
            "title": "Ts"
          }
        },
        "title": "TypeScript"
      },
      {
        "path": "/vue",
        "component": require('/Users/lianyafeng/Desktop/学习demo/dumi/myapp/src/vue.md').default,
        "exact": true,
        "meta": {
          "filePath": "src/vue.md",
          "updatedTime": 1627039504381,
          "slugs": [
            {
              "depth": 1,
              "value": "vue",
              "heading": "vue"
            },
            {
              "depth": 2,
              "value": "数据响应式",
              "heading": "数据响应式"
            },
            {
              "depth": 2,
              "value": "vue nextTick",
              "heading": "vue-nexttick"
            },
            {
              "depth": 2,
              "value": "vue 生命周期的作用是什么",
              "heading": "vue-生命周期的作用是什么"
            },
            {
              "depth": 2,
              "value": "第一次页面加载会触发哪几个钩子",
              "heading": "第一次页面加载会触发哪几个钩子"
            },
            {
              "depth": 2,
              "value": "简述每个周期具体适合哪些场景",
              "heading": "简述每个周期具体适合哪些场景"
            },
            {
              "depth": 2,
              "value": "created 和 mounted 的区别",
              "heading": "created-和-mounted-的区别"
            },
            {
              "depth": 2,
              "value": "vue 获取数据在哪个周期函数",
              "heading": "vue-获取数据在哪个周期函数"
            },
            {
              "depth": 2,
              "value": "mvvm",
              "heading": "mvvm"
            },
            {
              "depth": 2,
              "value": "vue-router 是什么?它有哪些组件",
              "heading": "vue-router-是什么它有哪些组件"
            },
            {
              "depth": 2,
              "value": "active-class 是哪个组件的属性？",
              "heading": "active-class-是哪个组件的属性？"
            },
            {
              "depth": 2,
              "value": "怎么定义 vue-router 的动态路由? 怎么获取传过来的值",
              "heading": "怎么定义-vue-router-的动态路由-怎么获取传过来的值"
            },
            {
              "depth": 2,
              "value": "vue-router 有哪几种导航钩子?",
              "heading": "vue-router-有哪几种导航钩子"
            },
            {
              "depth": 2,
              "value": "$route 和 $router 的区别",
              "heading": "route-和-router-的区别"
            },
            {
              "depth": 2,
              "value": "vue-router 响应路由参数的变化",
              "heading": "vue-router-响应路由参数的变化"
            },
            {
              "depth": 2,
              "value": "vue-router 传参",
              "heading": "vue-router-传参"
            },
            {
              "depth": 2,
              "value": "vue 优点",
              "heading": "vue-优点"
            },
            {
              "depth": 2,
              "value": "vue 父组件向子组件传递数据？",
              "heading": "vue-父组件向子组件传递数据？"
            },
            {
              "depth": 2,
              "value": "子组件像父组件传递事件",
              "heading": "子组件像父组件传递事件"
            },
            {
              "depth": 2,
              "value": "如何让 CSS 只在当前组件中起作用",
              "heading": "如何让-css-只在当前组件中起作用"
            },
            {
              "depth": 2,
              "value": "<keep-alive></keep-alive>的作用是什么?",
              "heading": "keep-alivekeep-alive的作用是什么"
            },
            {
              "depth": 2,
              "value": "如何获取 dom",
              "heading": "如何获取-dom"
            },
            {
              "depth": 2,
              "value": "vue-loader 是什么？使用它的途径有哪些？",
              "heading": "vue-loader-是什么？使用它的途径有哪些？"
            },
            {
              "depth": 2,
              "value": "为什么使用 key",
              "heading": "为什么使用-key"
            },
            {
              "depth": 2,
              "value": "axios 解决跨域",
              "heading": "axios-解决跨域"
            },
            {
              "depth": 2,
              "value": "vue-cli 项目中 src 目录每个文件夹和文件的用法",
              "heading": "vue-cli-项目中-src-目录每个文件夹和文件的用法"
            },
            {
              "depth": 2,
              "value": "分别简述 computed 和 watch 的使用场景",
              "heading": "分别简述-computed-和-watch-的使用场景"
            },
            {
              "depth": 2,
              "value": "v-on 可以监听多个方法吗",
              "heading": "v-on-可以监听多个方法吗"
            },
            {
              "depth": 2,
              "value": "vue 组件中 data 为什么必须是一个函数",
              "heading": "vue-组件中-data-为什么必须是一个函数"
            },
            {
              "depth": 2,
              "value": "vue 事件对象的使用",
              "heading": "vue-事件对象的使用"
            },
            {
              "depth": 2,
              "value": "单页面应用和多页面应用区别及优缺点",
              "heading": "单页面应用和多页面应用区别及优缺点"
            },
            {
              "depth": 2,
              "value": "assets 和 static 的区别",
              "heading": "assets-和-static-的区别"
            },
            {
              "depth": 2,
              "value": "列举常用的指令",
              "heading": "列举常用的指令"
            },
            {
              "depth": 2,
              "value": "vue 常用的修饰符",
              "heading": "vue-常用的修饰符"
            },
            {
              "depth": 2,
              "value": "数组更新检测",
              "heading": "数组更新检测"
            },
            {
              "depth": 2,
              "value": "Vue.set 视图更新",
              "heading": "vueset-视图更新"
            },
            {
              "depth": 2,
              "value": "自定义指令详解",
              "heading": "自定义指令详解"
            },
            {
              "depth": 2,
              "value": "vue 的两个核心点",
              "heading": "vue-的两个核心点"
            },
            {
              "depth": 2,
              "value": "vue 和 jQuery 的区别",
              "heading": "vue-和-jquery-的区别"
            },
            {
              "depth": 2,
              "value": "引进组件的步骤",
              "heading": "引进组件的步骤"
            },
            {
              "depth": 2,
              "value": "Vue-cli 打包命令是什么？打包后悔导致路径问题，应该在哪里修改",
              "heading": "vue-cli-打包命令是什么？打包后悔导致路径问题，应该在哪里修改"
            },
            {
              "depth": 2,
              "value": "跨组件双向数据绑定",
              "heading": "跨组件双向数据绑定"
            },
            {
              "depth": 2,
              "value": "delete 和 Vue.delete 删除数组的区别",
              "heading": "delete-和-vuedelete-删除数组的区别"
            },
            {
              "depth": 2,
              "value": "SPA 首屏加载慢如何解决",
              "heading": "spa-首屏加载慢如何解决"
            },
            {
              "depth": 2,
              "value": "Vue-router 跳转和 location.href 有什么区别",
              "heading": "vue-router-跳转和-locationhref-有什么区别"
            },
            {
              "depth": 2,
              "value": "你们 vue 项目是打包了一个 js 文件，一个 css 文件，还是有多个文件？",
              "heading": "你们-vue-项目是打包了一个-js-文件，一个-css-文件，还是有多个文件？"
            },
            {
              "depth": 2,
              "value": "vue 遇到的坑，如何解决的？",
              "heading": "vue-遇到的坑，如何解决的？"
            },
            {
              "depth": 2,
              "value": "Vue 里面 router-link 在电脑上有用，在安卓上没反应怎么解决？",
              "heading": "vue-里面-router-link-在电脑上有用，在安卓上没反应怎么解决？"
            },
            {
              "depth": 2,
              "value": "Vue2 中注册在 router-link 上事件无效解决方法",
              "heading": "vue2-中注册在-router-link-上事件无效解决方法"
            },
            {
              "depth": 2,
              "value": "RouterLink 在 IE 和 Firefox 中不起作用（路由不跳转）的问题",
              "heading": "routerlink-在-ie-和-firefox-中不起作用（路由不跳转）的问题"
            },
            {
              "depth": 2,
              "value": "axios 的特点有哪些",
              "heading": "axios-的特点有哪些"
            },
            {
              "depth": 2,
              "value": "请说下封装 vue 组件的过程？",
              "heading": "请说下封装-vue-组件的过程？"
            },
            {
              "depth": 2,
              "value": "vue mock 数据",
              "heading": "vue-mock-数据"
            },
            {
              "depth": 2,
              "value": "vue 封装通用组件",
              "heading": "vue-封装通用组件"
            },
            {
              "depth": 2,
              "value": "vue 初始化页面闪动问题",
              "heading": "vue-初始化页面闪动问题"
            },
            {
              "depth": 2,
              "value": "vue 禁止弹窗后的屏幕滚动",
              "heading": "vue-禁止弹窗后的屏幕滚动"
            },
            {
              "depth": 2,
              "value": "vue 更新数组时触发视图更新的方法",
              "heading": "vue-更新数组时触发视图更新的方法"
            },
            {
              "depth": 3,
              "value": "1.",
              "heading": "1"
            },
            {
              "depth": 3,
              "value": "2.当需要对象合并的时候需要用到 lodash _.merge(对象 1，对象 2)",
              "heading": "2当需要对象合并的时候需要用到-lodash-_merge对象-1，对象-2"
            },
            {
              "depth": 3,
              "value": "3.项目优化策略",
              "heading": "3项目优化策略"
            },
            {
              "depth": 1,
              "value": "vuex",
              "heading": "vuex"
            },
            {
              "depth": 2,
              "value": "使用 vuex 的目的",
              "heading": "使用-vuex-的目的"
            },
            {
              "depth": 2,
              "value": "state",
              "heading": "state"
            },
            {
              "depth": 2,
              "value": "getter",
              "heading": "getter"
            },
            {
              "depth": 2,
              "value": "mutation",
              "heading": "mutation"
            },
            {
              "depth": 2,
              "value": "action",
              "heading": "action"
            },
            {
              "depth": 2,
              "value": "module",
              "heading": "module"
            },
            {
              "depth": 2,
              "value": "provide 和 inject",
              "heading": "provide-和-inject"
            },
            {
              "depth": 2,
              "value": "vue.observable()",
              "heading": "vueobservable"
            },
            {
              "depth": 2,
              "value": "vue3",
              "heading": "vue3"
            },
            {
              "depth": 2,
              "value": "Ajv",
              "heading": "ajv"
            },
            {
              "depth": 2,
              "value": "在不实用proxy的前提下 实现defineProperty可以新增数据",
              "heading": "在不实用proxy的前提下-实现defineproperty可以新增数据"
            }
          ],
          "title": "vue",
          "nav": {
            "path": "/vue",
            "title": "Vue"
          }
        },
        "title": "vue"
      },
      {
        "path": "/vue学习文档",
        "component": require('/Users/lianyafeng/Desktop/学习demo/dumi/myapp/src/vue学习文档.md').default,
        "exact": true,
        "meta": {
          "filePath": "src/vue学习文档.md",
          "updatedTime": 1622039411703,
          "slugs": [
            {
              "depth": 3,
              "value": "1.v-cloak 闪动",
              "heading": "1v-cloak-闪动"
            },
            {
              "depth": 3,
              "value": "2.v-text 无闪动",
              "heading": "2v-text-无闪动"
            },
            {
              "depth": 3,
              "value": "3.v-html 插入html",
              "heading": "3v-html-插入html"
            },
            {
              "depth": 3,
              "value": "4.v-pre 显示原始信息 跳过编译过程",
              "heading": "4v-pre-显示原始信息-跳过编译过程"
            },
            {
              "depth": 3,
              "value": "5.数据响应式",
              "heading": "5数据响应式"
            },
            {
              "depth": 3,
              "value": "6.v-once 使页面上的内容只编译一次",
              "heading": "6v-once-使页面上的内容只编译一次"
            },
            {
              "depth": 3,
              "value": "7.双向数据绑定",
              "heading": "7双向数据绑定"
            },
            {
              "depth": 3,
              "value": "8.MVVM设计思想",
              "heading": "8mvvm设计思想"
            },
            {
              "depth": 3,
              "value": "9.事件绑定",
              "heading": "9事件绑定"
            },
            {
              "depth": 4,
              "value": "v-on",
              "heading": "v-on"
            },
            {
              "depth": 3,
              "value": "10.样式绑定",
              "heading": "10样式绑定"
            },
            {
              "depth": 3,
              "value": "11.v-for",
              "heading": "11v-for"
            },
            {
              "depth": 3,
              "value": "12.@click.prevent 阻止事件的默认行为",
              "heading": "12clickprevent-阻止事件的默认行为"
            },
            {
              "depth": 3,
              "value": "13.让select标签多选",
              "heading": "13让select标签多选"
            },
            {
              "depth": 3,
              "value": "14.v-model.number 将文本框的字符串转换成数值 可以直接运算",
              "heading": "14v-modelnumber-将文本框的字符串转换成数值-可以直接运算"
            },
            {
              "depth": 3,
              "value": "15. v-model.lazy",
              "heading": "15-v-modellazy"
            },
            {
              "depth": 3,
              "value": "16自定义指令",
              "heading": "16自定义指令"
            },
            {
              "depth": 3,
              "value": "17.带参数的自定义指令",
              "heading": "17带参数的自定义指令"
            },
            {
              "depth": 3,
              "value": "18.局部指令",
              "heading": "18局部指令"
            },
            {
              "depth": 3,
              "value": "19.计算属性",
              "heading": "19计算属性"
            },
            {
              "depth": 3,
              "value": "20.侦听器",
              "heading": "20侦听器"
            },
            {
              "depth": 3,
              "value": "21.过滤器",
              "heading": "21过滤器"
            },
            {
              "depth": 3,
              "value": "22.生命周期",
              "heading": "22生命周期"
            },
            {
              "depth": 3,
              "value": "22.vue的数组",
              "heading": "22vue的数组"
            },
            {
              "depth": 3,
              "value": "23.动态处理响应式数据",
              "heading": "23动态处理响应式数据"
            },
            {
              "depth": 3,
              "value": "24.filter过滤器",
              "heading": "24filter过滤器"
            },
            {
              "depth": 3,
              "value": "25.组件注册",
              "heading": "25组件注册"
            },
            {
              "depth": 3,
              "value": "26.组件间数据交互",
              "heading": "26组件间数据交互"
            },
            {
              "depth": 3,
              "value": "27.非父子组件间传值",
              "heading": "27非父子组件间传值"
            },
            {
              "depth": 3,
              "value": "28.组件插槽基本用法",
              "heading": "28组件插槽基本用法"
            },
            {
              "depth": 3,
              "value": "29.作用域插槽",
              "heading": "29作用域插槽"
            },
            {
              "depth": 3,
              "value": "30.blur失去焦点时触发事件",
              "heading": "30blur失去焦点时触发事件"
            },
            {
              "depth": 3,
              "value": "31.异步调用",
              "heading": "31异步调用"
            },
            {
              "depth": 3,
              "value": "31.Promise概述（处理回调函数嵌套变为线性",
              "heading": "31promise概述（处理回调函数嵌套变为线性"
            },
            {
              "depth": 3,
              "value": "32.Promise 基本用法",
              "heading": "32promise-基本用法"
            },
            {
              "depth": 3,
              "value": "33.promise常用的api",
              "heading": "33promise常用的api"
            },
            {
              "depth": 3,
              "value": "34.Promise的对象方法",
              "heading": "34promise的对象方法"
            },
            {
              "depth": 3,
              "value": "35.接口调用fetch用法",
              "heading": "35接口调用fetch用法"
            },
            {
              "depth": 3,
              "value": "36.axios的基本特性",
              "heading": "36axios的基本特性"
            },
            {
              "depth": 3,
              "value": "37.axios的参数传递",
              "heading": "37axios的参数传递"
            },
            {
              "depth": 3,
              "value": "38.axios的响应结果",
              "heading": "38axios的响应结果"
            },
            {
              "depth": 3,
              "value": "39.axios 拦截器",
              "heading": "39axios-拦截器"
            },
            {
              "depth": 3,
              "value": "40.async/await的基本用法",
              "heading": "40asyncawait的基本用法"
            },
            {
              "depth": 3,
              "value": "41.async/await的基本用法",
              "heading": "41asyncawait的基本用法"
            },
            {
              "depth": 3,
              "value": "42.路由",
              "heading": "42路由"
            },
            {
              "depth": 3,
              "value": "43.vue router",
              "heading": "43vue-router"
            },
            {
              "depth": 3,
              "value": "44.模块化",
              "heading": "44模块化"
            },
            {
              "depth": 3,
              "value": "45.commonJS规范",
              "heading": "45commonjs规范"
            },
            {
              "depth": 3,
              "value": "46.ES6模块化规范标准",
              "heading": "46es6模块化规范标准"
            },
            {
              "depth": 3,
              "value": "47 babel",
              "heading": "47-babel"
            },
            {
              "depth": 3,
              "value": "48.webpack",
              "heading": "48webpack"
            },
            {
              "depth": 3,
              "value": "49.webpack 配置",
              "heading": "49webpack-配置"
            },
            {
              "depth": 3,
              "value": "50.webpack自动打包功能",
              "heading": "50webpack自动打包功能"
            },
            {
              "depth": 3,
              "value": "51.webpack配置插件",
              "heading": "51webpack配置插件"
            },
            {
              "depth": 3,
              "value": "52.webpack 打包完成后自动打开浏览器显示项目",
              "heading": "52webpack-打包完成后自动打开浏览器显示项目"
            },
            {
              "depth": 3,
              "value": "53.webpack loader 加载器",
              "heading": "53webpack-loader-加载器"
            },
            {
              "depth": 3,
              "value": "54.处理css浏览器兼容性问题",
              "heading": "54处理css浏览器兼容性问题"
            },
            {
              "depth": 3,
              "value": "55.加载图片和文件字体",
              "heading": "55加载图片和文件字体"
            },
            {
              "depth": 3,
              "value": "56.打包处理js文件中的高级语法",
              "heading": "56打包处理js文件中的高级语法"
            },
            {
              "depth": 3,
              "value": "57.webpack 配置 vue组件的加载器",
              "heading": "57webpack-配置-vue组件的加载器"
            },
            {
              "depth": 3,
              "value": "58. 在webpack项目中使用vue",
              "heading": "58-在webpack项目中使用vue"
            },
            {
              "depth": 3,
              "value": "59.打包发布",
              "heading": "59打包发布"
            },
            {
              "depth": 3,
              "value": "60.git 创建分枝",
              "heading": "60git-创建分枝"
            },
            {
              "depth": 3,
              "value": "61. vue路由导航守卫",
              "heading": "61-vue路由导航守卫"
            },
            {
              "depth": 3,
              "value": "62.vue为开发模式与发布模式指定不同的打包入口",
              "heading": "62vue为开发模式与发布模式指定不同的打包入口"
            },
            {
              "depth": 3,
              "value": "63.configureWebpack 和 chainWebpack",
              "heading": "63configurewebpack-和-chainwebpack"
            },
            {
              "depth": 3,
              "value": "64.vue nextTick",
              "heading": "64vue-nexttick"
            }
          ],
          "title": "1.v-cloak 闪动",
          "nav": {
            "path": "/vue学习文档",
            "title": "Vue学习文档"
          }
        },
        "title": "1.v-cloak 闪动"
      },
      {
        "path": "/websocket",
        "component": require('/Users/lianyafeng/Desktop/学习demo/dumi/myapp/src/websocket.md').default,
        "exact": true,
        "meta": {
          "filePath": "src/websocket.md",
          "updatedTime": 1627058172922,
          "slugs": [],
          "title": "Websocket",
          "nav": {
            "path": "/websocket",
            "title": "Websocket"
          }
        },
        "title": "Websocket"
      },
      {
        "path": "/工程化",
        "component": require('/Users/lianyafeng/Desktop/学习demo/dumi/myapp/src/工程化.md').default,
        "exact": true,
        "meta": {
          "filePath": "src/工程化.md",
          "updatedTime": 1627020224723,
          "slugs": [
            {
              "depth": 1,
              "value": "工程化",
              "heading": "工程化"
            },
            {
              "depth": 2,
              "value": "工厂模式",
              "heading": "工厂模式"
            },
            {
              "depth": 2,
              "value": "BRD 和 SRS",
              "heading": "brd-和-srs"
            },
            {
              "depth": 2,
              "value": "软件开发的五个阶段",
              "heading": "软件开发的五个阶段"
            },
            {
              "depth": 2,
              "value": "yarn 与 npm的区别",
              "heading": "yarn-与-npm的区别"
            },
            {
              "depth": 2,
              "value": "git工作流",
              "heading": "git工作流"
            },
            {
              "depth": 2,
              "value": "webpack的作用",
              "heading": "webpack的作用"
            },
            {
              "depth": 2,
              "value": "webpack 与grunt、gulp的不同",
              "heading": "webpack-与grunt、gulp的不同"
            },
            {
              "depth": 2,
              "value": "常见的loader",
              "heading": "常见的loader"
            },
            {
              "depth": 2,
              "value": "常见的plugin",
              "heading": "常见的plugin"
            },
            {
              "depth": 2,
              "value": "loader和plugin的不同",
              "heading": "loader和plugin的不同"
            },
            {
              "depth": 2,
              "value": "webpack 的构建流程",
              "heading": "webpack-的构建流程"
            }
          ],
          "title": "工程化",
          "nav": {
            "path": "/工程化",
            "title": "工程化"
          }
        },
        "title": "工程化"
      },
      {
        "path": "/浏览器",
        "component": require('/Users/lianyafeng/Desktop/学习demo/dumi/myapp/src/浏览器.md').default,
        "exact": true,
        "meta": {
          "filePath": "src/浏览器.md",
          "updatedTime": 1627135426468,
          "slugs": [
            {
              "depth": 2,
              "value": "网络协议",
              "heading": "网络协议"
            },
            {
              "depth": 2,
              "value": "http",
              "heading": "http"
            },
            {
              "depth": 2,
              "value": "https",
              "heading": "https"
            },
            {
              "depth": 2,
              "value": "UDP",
              "heading": "udp"
            },
            {
              "depth": 2,
              "value": "TCP",
              "heading": "tcp"
            },
            {
              "depth": 2,
              "value": "DNS",
              "heading": "dns"
            },
            {
              "depth": 4,
              "value": "在地址栏里输入一个 URL,到这个页面呈现出来，中间会发生什么？",
              "heading": "在地址栏里输入一个-url到这个页面呈现出来，中间会发生什么？"
            },
            {
              "depth": 2,
              "value": "websocket",
              "heading": "websocket"
            },
            {
              "depth": 3,
              "value": "后端 node",
              "heading": "后端-node"
            },
            {
              "depth": 4,
              "value": "安装包",
              "heading": "安装包"
            },
            {
              "depth": 4,
              "value": "创建对象",
              "heading": "创建对象"
            },
            {
              "depth": 4,
              "value": "监听事件",
              "heading": "监听事件"
            },
            {
              "depth": 4,
              "value": "发送数据",
              "heading": "发送数据"
            },
            {
              "depth": 3,
              "value": "前端",
              "heading": "前端"
            },
            {
              "depth": 4,
              "value": "创建对象",
              "heading": "创建对象-1"
            },
            {
              "depth": 4,
              "value": "监听事件",
              "heading": "监听事件-1"
            },
            {
              "depth": 4,
              "value": "发送数据",
              "heading": "发送数据-1"
            },
            {
              "depth": 2,
              "value": "性能优化",
              "heading": "性能优化"
            },
            {
              "depth": 2,
              "value": "如何优化性能",
              "heading": "如何优化性能"
            },
            {
              "depth": 3,
              "value": "浏览器缓存策略",
              "heading": "浏览器缓存策略"
            },
            {
              "depth": 2,
              "value": "静态资源的加载",
              "heading": "静态资源的加载"
            },
            {
              "depth": 3,
              "value": "cdn 静态资源服务器 缓存",
              "heading": "cdn-静态资源服务器-缓存"
            },
            {
              "depth": 2,
              "value": "html和dom有什么不同",
              "heading": "html和dom有什么不同"
            }
          ],
          "title": "网络协议",
          "nav": {
            "path": "/浏览器",
            "title": "浏览器"
          }
        },
        "title": "网络协议"
      },
      {
        "path": "/电商管理后台 api 接口文档",
        "component": require('/Users/lianyafeng/Desktop/学习demo/dumi/myapp/src/电商管理后台 API 接口文档.md').default,
        "exact": true,
        "meta": {
          "filePath": "src/电商管理后台 API 接口文档.md",
          "updatedTime": 1621144243884,
          "slugs": [
            {
              "depth": 1,
              "value": "1. 电商管理后台 API 接口文档",
              "heading": "1-电商管理后台-api-接口文档"
            },
            {
              "depth": 2,
              "value": "1.1. API V1 接口说明",
              "heading": "11-api-v1-接口说明"
            },
            {
              "depth": 3,
              "value": "1.1.1. 支持的请求方法",
              "heading": "111-支持的请求方法"
            },
            {
              "depth": 3,
              "value": "1.1.2. 通用返回状态说明",
              "heading": "112-通用返回状态说明"
            },
            {
              "depth": 2,
              "value": "1.2. 登录",
              "heading": "12-登录"
            },
            {
              "depth": 3,
              "value": "1.2.1. 登录验证接口",
              "heading": "121-登录验证接口"
            },
            {
              "depth": 2,
              "value": "1.3. 用户管理",
              "heading": "13-用户管理"
            },
            {
              "depth": 3,
              "value": "1.3.1. 用户数据列表",
              "heading": "131-用户数据列表"
            },
            {
              "depth": 3,
              "value": "1.3.2. 添加用户",
              "heading": "132-添加用户"
            },
            {
              "depth": 3,
              "value": "1.3.3. 修改用户状态",
              "heading": "133-修改用户状态"
            },
            {
              "depth": 3,
              "value": "1.3.4. 根据 ID 查询用户信息",
              "heading": "134-根据-id-查询用户信息"
            },
            {
              "depth": 3,
              "value": "1.3.5. 编辑用户提交",
              "heading": "135-编辑用户提交"
            },
            {
              "depth": 3,
              "value": "1.3.6. 删除单个用户",
              "heading": "136-删除单个用户"
            },
            {
              "depth": 3,
              "value": "1.3.7. 分配用户角色",
              "heading": "137-分配用户角色"
            },
            {
              "depth": 2,
              "value": "1.4. 权限管理",
              "heading": "14-权限管理"
            },
            {
              "depth": 3,
              "value": "1.4.1. 所有权限列表",
              "heading": "141-所有权限列表"
            },
            {
              "depth": 3,
              "value": "1.4.2. 左侧菜单权限",
              "heading": "142-左侧菜单权限"
            },
            {
              "depth": 2,
              "value": "1.5. 角色管理",
              "heading": "15-角色管理"
            },
            {
              "depth": 3,
              "value": "1.5.1. 角色列表",
              "heading": "151-角色列表"
            },
            {
              "depth": 3,
              "value": "1.5.2. 添加角色",
              "heading": "152-添加角色"
            },
            {
              "depth": 3,
              "value": "1.5.3. 根据 ID 查询角色",
              "heading": "153-根据-id-查询角色"
            },
            {
              "depth": 3,
              "value": "1.5.4. 编辑提交角色",
              "heading": "154-编辑提交角色"
            },
            {
              "depth": 3,
              "value": "1.5.5. 删除角色",
              "heading": "155-删除角色"
            },
            {
              "depth": 3,
              "value": "1.5.6. 角色授权",
              "heading": "156-角色授权"
            },
            {
              "depth": 3,
              "value": "1.5.7. 删除角色指定权限",
              "heading": "157-删除角色指定权限"
            },
            {
              "depth": 2,
              "value": "1.6. 商品分类管理",
              "heading": "16-商品分类管理"
            },
            {
              "depth": 3,
              "value": "1.6.1. 商品分类数据列表",
              "heading": "161-商品分类数据列表"
            },
            {
              "depth": 3,
              "value": "1.6.2. 添加分类",
              "heading": "162-添加分类"
            },
            {
              "depth": 3,
              "value": "1.6.3. 根据 id 查询分类",
              "heading": "163-根据-id-查询分类"
            },
            {
              "depth": 3,
              "value": "1.6.4. 编辑提交分类",
              "heading": "164-编辑提交分类"
            },
            {
              "depth": 3,
              "value": "1.6.5. 删除分类",
              "heading": "165-删除分类"
            },
            {
              "depth": 2,
              "value": "1.7. 分类参数管理",
              "heading": "17-分类参数管理"
            },
            {
              "depth": 3,
              "value": "1.7.1. 参数列表",
              "heading": "171-参数列表"
            },
            {
              "depth": 3,
              "value": "1.7.2. 添加动态参数或者静态属性",
              "heading": "172-添加动态参数或者静态属性"
            },
            {
              "depth": 3,
              "value": "1.7.3. 删除参数",
              "heading": "173-删除参数"
            },
            {
              "depth": 3,
              "value": "1.7.4. 根据 ID 查询参数",
              "heading": "174-根据-id-查询参数"
            },
            {
              "depth": 3,
              "value": "1.7.5. 编辑提交参数",
              "heading": "175-编辑提交参数"
            },
            {
              "depth": 2,
              "value": "1.8. 商品管理",
              "heading": "18-商品管理"
            },
            {
              "depth": 3,
              "value": "1.8.1. 商品列表数据",
              "heading": "181-商品列表数据"
            },
            {
              "depth": 3,
              "value": "1.8.2. 添加商品",
              "heading": "182-添加商品"
            },
            {
              "depth": 3,
              "value": "1.8.3. 根据 ID 查询商品",
              "heading": "183-根据-id-查询商品"
            },
            {
              "depth": 3,
              "value": "1.8.4. 编辑提交商品",
              "heading": "184-编辑提交商品"
            },
            {
              "depth": 3,
              "value": "1.8.5. 删除商品",
              "heading": "185-删除商品"
            },
            {
              "depth": 2,
              "value": "1.9. 图片上传",
              "heading": "19-图片上传"
            },
            {
              "depth": 2,
              "value": "1.10. 订单管理",
              "heading": "110-订单管理"
            },
            {
              "depth": 3,
              "value": "1.10.1. 订单数据列表",
              "heading": "1101-订单数据列表"
            },
            {
              "depth": 3,
              "value": "1.10.2. 修改订单状态",
              "heading": "1102-修改订单状态"
            },
            {
              "depth": 3,
              "value": "1.10.3. 查看订单详情",
              "heading": "1103-查看订单详情"
            },
            {
              "depth": 3,
              "value": "1.10.4. 修改地址",
              "heading": "1104-修改地址"
            },
            {
              "depth": 3,
              "value": "1.10.5. 查看物流信息",
              "heading": "1105-查看物流信息"
            },
            {
              "depth": 2,
              "value": "1.11. 数据统计",
              "heading": "111-数据统计"
            },
            {
              "depth": 3,
              "value": "1.11.1.  基于时间统计的折线图",
              "heading": "1111--基于时间统计的折线图"
            }
          ],
          "title": "1. 电商管理后台 API 接口文档",
          "nav": {
            "path": "/电商管理后台 api 接口文档",
            "title": "电商管理后台 api 接口文档"
          }
        },
        "title": "1. 电商管理后台 API 接口文档"
      },
      {
        "path": "/components/foo",
        "component": require('/Users/lianyafeng/Desktop/学习demo/dumi/myapp/src/Foo/index.md').default,
        "exact": true,
        "meta": {
          "filePath": "src/Foo/index.md",
          "updatedTime": 1621160862211,
          "componentName": "Foo",
          "nav": {
            "title": "Components",
            "path": "/components"
          },
          "slugs": [
            {
              "depth": 2,
              "value": "Foo",
              "heading": "foo"
            }
          ],
          "title": "Foo",
          "group": {
            "path": "/components/foo",
            "title": "Foo"
          }
        },
        "title": "Foo"
      },
      {
        "path": "/zh-CN/getting-started",
        "component": require('/Users/lianyafeng/Desktop/学习demo/dumi/myapp/docs/getting-started.zh-CN.md').default,
        "exact": true,
        "meta": {
          "filePath": "docs/getting-started.zh-CN.md",
          "updatedTime": 1621160831487,
          "nav": {
            "title": "快速上手",
            "order": 1,
            "path": "/zh-CN/getting-started"
          },
          "slugs": [
            {
              "depth": 1,
              "value": "快速上手",
              "heading": "快速上手"
            }
          ],
          "title": "快速上手",
          "locale": "zh-CN"
        },
        "title": "快速上手"
      },
      {
        "path": "/zh-CN/help",
        "component": require('/Users/lianyafeng/Desktop/学习demo/dumi/myapp/docs/help.zh-CN.md').default,
        "exact": true,
        "meta": {
          "filePath": "docs/help.zh-CN.md",
          "updatedTime": 1621160831488,
          "nav": {
            "title": "帮助",
            "path": "/zh-CN/help"
          },
          "slugs": [
            {
              "depth": 1,
              "value": "帮助",
              "heading": "帮助"
            }
          ],
          "title": "帮助",
          "locale": "zh-CN"
        },
        "title": "帮助"
      },
      {
        "path": "/",
        "component": require('/Users/lianyafeng/Desktop/学习demo/dumi/myapp/docs/index.md').default,
        "exact": true,
        "meta": {
          "filePath": "docs/index.md",
          "updatedTime": 1621160862208,
          "hero": {
            "title": "myapp",
            "desc": "<div class=\"markdown\"><p>myapp site example</p></div>",
            "actions": [
              {
                "text": "Getting Started",
                "link": "/components"
              }
            ]
          },
          "features": [
            {
              "icon": "https://gw.alipayobjects.com/zos/bmw-prod/881dc458-f20b-407b-947a-95104b5ec82b/k79dm8ih_w144_h144.png",
              "title": "Feature 1",
              "desc": "<div class=\"markdown\"><p>Balabala</p></div>"
            },
            {
              "icon": "https://gw.alipayobjects.com/zos/bmw-prod/d60657df-0822-4631-9d7c-e7a869c2f21c/k79dmz3q_w126_h126.png",
              "title": "Feature 2",
              "desc": "<div class=\"markdown\"><p>Balabala</p></div>"
            },
            {
              "icon": "https://gw.alipayobjects.com/zos/bmw-prod/d1ee0c6f-5aed-4a45-a507-339a4bfe076c/k7bjsocq_w144_h144.png",
              "title": "Feature 3",
              "desc": "<div class=\"markdown\"><p>Balabala</p></div>"
            }
          ],
          "footer": "<div class=\"markdown\"><p>Open-source MIT Licensed | Copyright © 2020<br />Powered by <a href=\"https://d.umijs.org/\" target=\"_blank\">dumi<svg xmlns=\"http://www.w3.org/2000/svg\" aria-hidden=\"\" x=\"0px\" y=\"0px\" viewBox=\"0 0 100 100\" width=\"15\" height=\"15\" class=\"__dumi-default-external-link-icon\"><path fill=\"currentColor\" d=\"M18.8,85.1h56l0,0c2.2,0,4-1.8,4-4v-32h-8v28h-48v-48h28v-8h-32l0,0c-2.2,0-4,1.8-4,4v56C14.8,83.3,16.6,85.1,18.8,85.1z\"></path><polygon fill=\"currentColor\" points=\"45.7,48.7 51.3,54.3 77.2,28.5 77.2,37.2 85.2,37.2 85.2,14.9 62.8,14.9 62.8,22.9 71.5,22.9\"></polygon></svg></a></p></div>",
          "slugs": [
            {
              "depth": 2,
              "value": "Hello myapp!",
              "heading": "hello-myapp"
            }
          ],
          "title": "Hello myapp!"
        },
        "title": "Hello myapp!"
      },
      {
        "path": "/zh-CN",
        "component": require('/Users/lianyafeng/Desktop/学习demo/dumi/myapp/docs/index.zh-CN.md').default,
        "exact": true,
        "meta": {
          "filePath": "docs/index.zh-CN.md",
          "updatedTime": 1621160831489,
          "hero": {
            "title": "Site Name",
            "desc": "<div class=\"markdown\"><p>dumi site app 脚手架</p></div>",
            "actions": [
              {
                "text": "快速上手",
                "link": "/getting-started"
              }
            ]
          },
          "features": [
            {
              "icon": "https://gw.alipayobjects.com/zos/bmw-prod/881dc458-f20b-407b-947a-95104b5ec82b/k79dm8ih_w144_h144.png",
              "title": "特性 1",
              "desc": "<div class=\"markdown\"><p>Balabala</p></div>"
            },
            {
              "icon": "https://gw.alipayobjects.com/zos/bmw-prod/d60657df-0822-4631-9d7c-e7a869c2f21c/k79dmz3q_w126_h126.png",
              "title": "特性 2",
              "desc": "<div class=\"markdown\"><p>Balabala</p></div>"
            },
            {
              "icon": "https://gw.alipayobjects.com/zos/bmw-prod/d1ee0c6f-5aed-4a45-a507-339a4bfe076c/k7bjsocq_w144_h144.png",
              "title": "特性 3",
              "desc": "<div class=\"markdown\"><p>Balabala</p></div>"
            }
          ],
          "footer": "<div class=\"markdown\"><p>Open-source MIT Licensed | Copyright © 2020<br />Powered by <a href=\"https://d.umijs.org/\" target=\"_blank\">dumi<svg xmlns=\"http://www.w3.org/2000/svg\" aria-hidden=\"\" x=\"0px\" y=\"0px\" viewBox=\"0 0 100 100\" width=\"15\" height=\"15\" class=\"__dumi-default-external-link-icon\"><path fill=\"currentColor\" d=\"M18.8,85.1h56l0,0c2.2,0,4-1.8,4-4v-32h-8v28h-48v-48h28v-8h-32l0,0c-2.2,0-4,1.8-4,4v56C14.8,83.3,16.6,85.1,18.8,85.1z\"></path><polygon fill=\"currentColor\" points=\"45.7,48.7 51.3,54.3 77.2,28.5 77.2,37.2 85.2,37.2 85.2,14.9 62.8,14.9 62.8,22.9 71.5,22.9\"></polygon></svg></a></p></div>",
          "slugs": [
            {
              "depth": 2,
              "value": "Hello dumi!",
              "heading": "hello-dumi"
            }
          ],
          "title": "Hello dumi!",
          "locale": "zh-CN"
        },
        "title": "Hello dumi!"
      },
      {
        "path": "/zh-CN/css",
        "component": require('/Users/lianyafeng/Desktop/学习demo/dumi/myapp/src/css.md').default,
        "exact": true,
        "meta": {
          "filePath": "src/css.md",
          "updatedTime": 1627059170883,
          "slugs": [
            {
              "depth": 1,
              "value": "CSS",
              "heading": "css"
            },
            {
              "depth": 2,
              "value": "清除浮动",
              "heading": "清除浮动"
            },
            {
              "depth": 2,
              "value": "盒模型",
              "heading": "盒模型"
            },
            {
              "depth": 2,
              "value": "transition 和animation的区别",
              "heading": "transition-和animation的区别"
            },
            {
              "depth": 2,
              "value": "BFC",
              "heading": "bfc"
            },
            {
              "depth": 3,
              "value": "BFC的理解",
              "heading": "bfc的理解"
            },
            {
              "depth": 3,
              "value": "规则",
              "heading": "规则"
            },
            {
              "depth": 3,
              "value": "BFC中的盒子对齐",
              "heading": "bfc中的盒子对齐"
            },
            {
              "depth": 3,
              "value": "外边距重叠",
              "heading": "外边距重叠"
            },
            {
              "depth": 2,
              "value": "Flex",
              "heading": "flex"
            },
            {
              "depth": 2,
              "value": "解决css阻塞污染的问题",
              "heading": "解决css阻塞污染的问题"
            },
            {
              "depth": 2,
              "value": "css 的缩放、渐变、旋转和平移",
              "heading": "css-的缩放、渐变、旋转和平移"
            },
            {
              "depth": 2,
              "value": "三栏布局 的5种方案",
              "heading": "三栏布局-的5种方案"
            },
            {
              "depth": 2,
              "value": "圣杯布局 的三种方案",
              "heading": "圣杯布局-的三种方案"
            },
            {
              "depth": 2,
              "value": "吸顶布局",
              "heading": "吸顶布局"
            }
          ],
          "title": "CSS",
          "nav": {
            "path": "/zh-CN/css",
            "title": "Css"
          },
          "locale": "zh-CN"
        },
        "title": "CSS"
      },
      {
        "path": "/zh-CN/functional-javascript",
        "component": require('/Users/lianyafeng/Desktop/学习demo/dumi/myapp/src/functional-javascript.md').default,
        "exact": true,
        "meta": {
          "filePath": "src/functional-javascript.md",
          "updatedTime": 1626156067289,
          "slugs": [
            {
              "depth": 2,
              "value": "Hello world",
              "heading": "hello-world"
            },
            {
              "depth": 2,
              "value": "Higher Order Functions",
              "heading": "higher-order-functions"
            },
            {
              "depth": 2,
              "value": "map",
              "heading": "map"
            },
            {
              "depth": 2,
              "value": "Filter",
              "heading": "filter"
            },
            {
              "depth": 2,
              "value": "Basic: Every Some",
              "heading": "basic-every-some"
            },
            {
              "depth": 2,
              "value": "reduce",
              "heading": "reduce"
            },
            {
              "depth": 2,
              "value": "Basic：Recursion",
              "heading": "basic：recursion"
            },
            {
              "depth": 2,
              "value": "Basic: Call",
              "heading": "basic-call"
            },
            {
              "depth": 2,
              "value": "Partial Application without Bind",
              "heading": "partial-application-without-bind"
            },
            {
              "depth": 2,
              "value": "Partial Application with Bind",
              "heading": "partial-application-with-bind"
            },
            {
              "depth": 2,
              "value": "Implement Map with Reduce",
              "heading": "implement-map-with-reduce"
            },
            {
              "depth": 2,
              "value": "Function Spies",
              "heading": "function-spies"
            },
            {
              "depth": 2,
              "value": "Blocking Event Loop",
              "heading": "blocking-event-loop"
            },
            {
              "depth": 2,
              "value": "Trampoline",
              "heading": "trampoline"
            },
            {
              "depth": 2,
              "value": "Async Loops",
              "heading": "async-loops"
            },
            {
              "depth": 2,
              "value": "Recursion",
              "heading": "recursion"
            },
            {
              "depth": 2,
              "value": "Currying",
              "heading": "currying"
            },
            {
              "depth": 2,
              "value": "Function Call",
              "heading": "function-call"
            }
          ],
          "title": "Hello world",
          "nav": {
            "path": "/zh-CN/functional-javascript",
            "title": "Functional-javascript"
          },
          "locale": "zh-CN"
        },
        "title": "Hello world"
      },
      {
        "path": "/zh-CN/js",
        "component": require('/Users/lianyafeng/Desktop/学习demo/dumi/myapp/src/js.md').default,
        "exact": true,
        "meta": {
          "filePath": "src/js.md",
          "updatedTime": 1627130278339,
          "slugs": [
            {
              "depth": 2,
              "value": "拖拽",
              "heading": "拖拽"
            },
            {
              "depth": 2,
              "value": "原型/构造函数/实例",
              "heading": "原型构造函数实例"
            },
            {
              "depth": 2,
              "value": "原型链",
              "heading": "原型链"
            },
            {
              "depth": 2,
              "value": "JS 执行上下文",
              "heading": "js-执行上下文"
            },
            {
              "depth": 3,
              "value": "全局执行上下文",
              "heading": "全局执行上下文"
            },
            {
              "depth": 3,
              "value": "函数执行上下文",
              "heading": "函数执行上下文"
            },
            {
              "depth": 2,
              "value": "闭包",
              "heading": "闭包"
            },
            {
              "depth": 2,
              "value": "对象的拷贝",
              "heading": "对象的拷贝"
            },
            {
              "depth": 2,
              "value": "new 运算符的执行过程",
              "heading": "new-运算符的执行过程"
            },
            {
              "depth": 2,
              "value": "instanceof 原理",
              "heading": "instanceof-原理"
            },
            {
              "depth": 2,
              "value": "类型判断",
              "heading": "类型判断"
            },
            {
              "depth": 2,
              "value": "模块化",
              "heading": "模块化"
            },
            {
              "depth": 2,
              "value": "防抖与节流",
              "heading": "防抖与节流"
            },
            {
              "depth": 2,
              "value": "js的由来 以及单线程的原因",
              "heading": "js的由来-以及单线程的原因"
            },
            {
              "depth": 2,
              "value": "AST 抽象语法树",
              "heading": "ast-抽象语法树"
            },
            {
              "depth": 2,
              "value": "js代码的执行过程",
              "heading": "js代码的执行过程"
            },
            {
              "depth": 2,
              "value": "babel 编译原理",
              "heading": "babel-编译原理"
            },
            {
              "depth": 2,
              "value": "v8引擎运行的三个阶段",
              "heading": "v8引擎运行的三个阶段"
            },
            {
              "depth": 2,
              "value": "函数柯里化",
              "heading": "函数柯里化"
            },
            {
              "depth": 2,
              "value": "跨域",
              "heading": "跨域"
            },
            {
              "depth": 2,
              "value": "Event loop 中的 job queue",
              "heading": "event-loop-中的-job-queue"
            },
            {
              "depth": 2,
              "value": "更复杂的例子",
              "heading": "更复杂的例子"
            },
            {
              "depth": 2,
              "value": "实现 sleep 的效果",
              "heading": "实现-sleep-的效果"
            },
            {
              "depth": 3,
              "value": "通过 promise 的方式来实现",
              "heading": "通过-promise-的方式来实现"
            },
            {
              "depth": 2,
              "value": "Promise",
              "heading": "promise"
            },
            {
              "depth": 4,
              "value": "手写一个 promise",
              "heading": "手写一个-promise"
            },
            {
              "depth": 2,
              "value": "promise 的应用场景",
              "heading": "promise-的应用场景"
            },
            {
              "depth": 2,
              "value": "js 数组的方法",
              "heading": "js-数组的方法"
            },
            {
              "depth": 2,
              "value": "字符串的方法",
              "heading": "字符串的方法"
            },
            {
              "depth": 2,
              "value": "es6 新特性",
              "heading": "es6-新特性"
            },
            {
              "depth": 2,
              "value": "this",
              "heading": "this"
            },
            {
              "depth": 2,
              "value": "数组扁平化",
              "heading": "数组扁平化"
            },
            {
              "depth": 2,
              "value": "dom 的 api",
              "heading": "dom-的-api"
            },
            {
              "depth": 2,
              "value": "virtual dom",
              "heading": "virtual-dom"
            },
            {
              "depth": 2,
              "value": "function 可以 new 那么箭头函数可以吗",
              "heading": "function-可以-new-那么箭头函数可以吗"
            },
            {
              "depth": 2,
              "value": "JavaScript对象的底层数据结构是什么",
              "heading": "javascript对象的底层数据结构是什么"
            },
            {
              "depth": 2,
              "value": "基本类型对应的内置对象，以及他们之间的装箱拆箱操作",
              "heading": "基本类型对应的内置对象，以及他们之间的装箱拆箱操作"
            },
            {
              "depth": 2,
              "value": "null和undefined的区别",
              "heading": "null和undefined的区别"
            },
            {
              "depth": 2,
              "value": "判断数据类型的几种方法",
              "heading": "判断数据类型的几种方法"
            },
            {
              "depth": 2,
              "value": "es6 class的底层实现",
              "heading": "es6-class的底层实现"
            },
            {
              "depth": 2,
              "value": "理解词法作用域和动态作用域",
              "heading": "理解词法作用域和动态作用域"
            },
            {
              "depth": 2,
              "value": "理解堆栈溢出和内存泄漏的原理，如何防止",
              "heading": "理解堆栈溢出和内存泄漏的原理，如何防止"
            },
            {
              "depth": 2,
              "value": "如何处理循环的异步操作",
              "heading": "如何处理循环的异步操作"
            },
            {
              "depth": 2,
              "value": "理解模块化解决的实际问题，可列举几个模块化方案并理解其中原理",
              "heading": "理解模块化解决的实际问题，可列举几个模块化方案并理解其中原理"
            },
            {
              "depth": 2,
              "value": "为何try里面放return，finally还会执行，理解其内部机制",
              "heading": "为何try里面放return，finally还会执行，理解其内部机制"
            },
            {
              "depth": 2,
              "value": "Promise 并行和串行理解",
              "heading": "promise-并行和串行理解"
            },
            {
              "depth": 2,
              "value": "什么是高阶函数",
              "heading": "什么是高阶函数"
            },
            {
              "depth": 2,
              "value": "将伪数组转化为数组",
              "heading": "将伪数组转化为数组"
            }
          ],
          "title": "拖拽",
          "nav": {
            "path": "/zh-CN/js",
            "title": "Js"
          },
          "locale": "zh-CN"
        },
        "title": "拖拽"
      },
      {
        "path": "/zh-CN/node",
        "component": require('/Users/lianyafeng/Desktop/学习demo/dumi/myapp/src/node.md').default,
        "exact": true,
        "meta": {
          "filePath": "src/node.md",
          "updatedTime": 1624891891531,
          "slugs": [
            {
              "depth": 1,
              "value": "nodeJS学习",
              "heading": "nodejs学习"
            },
            {
              "depth": 2,
              "value": "node事件循环 event loop",
              "heading": "node事件循环-event-loop"
            },
            {
              "depth": 3,
              "value": "什么是事件循环",
              "heading": "什么是事件循环"
            },
            {
              "depth": 3,
              "value": "工作原理",
              "heading": "工作原理"
            },
            {
              "depth": 4,
              "value": "定义事件队列",
              "heading": "定义事件队列"
            },
            {
              "depth": 4,
              "value": "定义接受请求入口",
              "heading": "定义接受请求入口"
            },
            {
              "depth": 4,
              "value": "定义 Event loop",
              "heading": "定义-event-loop"
            },
            {
              "depth": 4,
              "value": "处理 I/O 任务",
              "heading": "处理-io-任务"
            },
            {
              "depth": 3,
              "value": "nodejs 的短板",
              "heading": "nodejs-的短板"
            },
            {
              "depth": 3,
              "value": "node的适用场景",
              "heading": "node的适用场景"
            },
            {
              "depth": 2,
              "value": "node的特征",
              "heading": "node的特征"
            },
            {
              "depth": 2,
              "value": "node解决跨域问题",
              "heading": "node解决跨域问题"
            },
            {
              "depth": 2,
              "value": "node 全局对象",
              "heading": "node-全局对象"
            },
            {
              "depth": 2,
              "value": "node process",
              "heading": "node-process"
            },
            {
              "depth": 2,
              "value": "node fs",
              "heading": "node-fs"
            },
            {
              "depth": 2,
              "value": "Buffer",
              "heading": "buffer"
            },
            {
              "depth": 2,
              "value": "react-travel",
              "heading": "react-travel"
            },
            {
              "depth": 3,
              "value": "技术栈",
              "heading": "技术栈"
            },
            {
              "depth": 3,
              "value": "模块",
              "heading": "模块"
            },
            {
              "depth": 3,
              "value": "koa、koa2、express",
              "heading": "koa、koa2、express"
            }
          ],
          "title": "nodeJS学习",
          "nav": {
            "path": "/zh-CN/node",
            "title": "Node"
          },
          "locale": "zh-CN"
        },
        "title": "nodeJS学习"
      },
      {
        "path": "/zh-CN/react",
        "component": require('/Users/lianyafeng/Desktop/学习demo/dumi/myapp/src/react.md').default,
        "exact": true,
        "meta": {
          "filePath": "src/react.md",
          "updatedTime": 1625648941818,
          "slugs": [
            {
              "depth": 1,
              "value": "react",
              "heading": "react"
            },
            {
              "depth": 2,
              "value": "react 是什么",
              "heading": "react-是什么"
            },
            {
              "depth": 2,
              "value": "react 的特点",
              "heading": "react-的特点"
            },
            {
              "depth": 2,
              "value": "安装",
              "heading": "安装"
            },
            {
              "depth": 2,
              "value": "使用",
              "heading": "使用"
            },
            {
              "depth": 2,
              "value": "脚手架create-react-app",
              "heading": "脚手架create-react-app"
            },
            {
              "depth": 2,
              "value": "npx",
              "heading": "npx"
            },
            {
              "depth": 2,
              "value": "jsx",
              "heading": "jsx"
            },
            {
              "depth": 2,
              "value": "组件",
              "heading": "组件"
            },
            {
              "depth": 3,
              "value": "函数组件",
              "heading": "函数组件"
            },
            {
              "depth": 3,
              "value": "类组件",
              "heading": "类组件"
            },
            {
              "depth": 2,
              "value": "复合组件",
              "heading": "复合组件"
            },
            {
              "depth": 2,
              "value": "State 状态",
              "heading": "state-状态"
            },
            {
              "depth": 2,
              "value": "props",
              "heading": "props"
            },
            {
              "depth": 2,
              "value": "props 验证",
              "heading": "props-验证"
            },
            {
              "depth": 2,
              "value": "事件处理",
              "heading": "事件处理"
            },
            {
              "depth": 2,
              "value": "条件渲染",
              "heading": "条件渲染"
            },
            {
              "depth": 2,
              "value": "列表渲染",
              "heading": "列表渲染"
            },
            {
              "depth": 2,
              "value": "react 组件 api",
              "heading": "react-组件-api"
            },
            {
              "depth": 2,
              "value": "react 的生命周期",
              "heading": "react-的生命周期"
            },
            {
              "depth": 2,
              "value": "表单处理",
              "heading": "表单处理"
            },
            {
              "depth": 3,
              "value": "受控组件",
              "heading": "受控组件"
            },
            {
              "depth": 3,
              "value": "非受控组件",
              "heading": "非受控组件"
            },
            {
              "depth": 3,
              "value": "组件评论练习",
              "heading": "组件评论练习"
            },
            {
              "depth": 2,
              "value": "props 接收数据",
              "heading": "props-接收数据"
            },
            {
              "depth": 3,
              "value": "props children 属性",
              "heading": "props-children-属性"
            },
            {
              "depth": 2,
              "value": "父子组件之间的通讯",
              "heading": "父子组件之间的通讯"
            },
            {
              "depth": 2,
              "value": "兄弟组件之间的通讯",
              "heading": "兄弟组件之间的通讯"
            },
            {
              "depth": 2,
              "value": "组件添加 props 校验",
              "heading": "组件添加-props-校验"
            },
            {
              "depth": 2,
              "value": "生命周期常用的钩子函数",
              "heading": "生命周期常用的钩子函数"
            },
            {
              "depth": 3,
              "value": "1.创建时",
              "heading": "1创建时"
            },
            {
              "depth": 3,
              "value": "2.更新时",
              "heading": "2更新时"
            },
            {
              "depth": 3,
              "value": "3.卸载时",
              "heading": "3卸载时"
            },
            {
              "depth": 2,
              "value": "高阶组件的作用",
              "heading": "高阶组件的作用"
            },
            {
              "depth": 3,
              "value": "render props 模式",
              "heading": "render-props-模式"
            },
            {
              "depth": 3,
              "value": "高阶组件",
              "heading": "高阶组件"
            },
            {
              "depth": 2,
              "value": "setState 更新数据是异步的",
              "heading": "setstate-更新数据是异步的"
            },
            {
              "depth": 3,
              "value": "setState 推荐语法",
              "heading": "setstate-推荐语法"
            },
            {
              "depth": 2,
              "value": "jsx 语法的转化过程",
              "heading": "jsx-语法的转化过程"
            },
            {
              "depth": 2,
              "value": "React 组件的更新机制",
              "heading": "react-组件的更新机制"
            },
            {
              "depth": 2,
              "value": "对组件进行性能优化",
              "heading": "对组件进行性能优化"
            },
            {
              "depth": 2,
              "value": "虚拟 DOM 和 Diff 算法",
              "heading": "虚拟-dom-和-diff-算法"
            },
            {
              "depth": 3,
              "value": "diff 算法 实质是找不同",
              "heading": "diff-算法-实质是找不同"
            },
            {
              "depth": 2,
              "value": "纯组件 PureComponent",
              "heading": "纯组件-purecomponent"
            },
            {
              "depth": 2,
              "value": "react-router-dom",
              "heading": "react-router-dom"
            },
            {
              "depth": 2,
              "value": "路由的执行过程",
              "heading": "路由的执行过程"
            },
            {
              "depth": 2,
              "value": "编程式导航",
              "heading": "编程式导航"
            },
            {
              "depth": 2,
              "value": "默认路由 进入页面时就会匹配的路由",
              "heading": "默认路由-进入页面时就会匹配的路由"
            },
            {
              "depth": 3,
              "value": "模糊匹配模式",
              "heading": "模糊匹配模式"
            },
            {
              "depth": 3,
              "value": "精确匹配",
              "heading": "精确匹配"
            },
            {
              "depth": 2,
              "value": "hooks",
              "heading": "hooks"
            },
            {
              "depth": 2,
              "value": "纯函数",
              "heading": "纯函数"
            },
            {
              "depth": 2,
              "value": "redux 数据仓库",
              "heading": "redux-数据仓库"
            },
            {
              "depth": 2,
              "value": "旅游网站业务",
              "heading": "旅游网站业务"
            },
            {
              "depth": 2,
              "value": "redux redux-toolkit",
              "heading": "redux-redux-toolkit"
            },
            {
              "depth": 2,
              "value": "redux-persist 登陆持久化",
              "heading": "redux-persist-登陆持久化"
            },
            {
              "depth": 2,
              "value": "发布流程",
              "heading": "发布流程"
            },
            {
              "depth": 2,
              "value": "docker",
              "heading": "docker"
            },
            {
              "depth": 2,
              "value": "docker的三个核心概念",
              "heading": "docker的三个核心概念"
            }
          ],
          "title": "react",
          "nav": {
            "path": "/zh-CN/react",
            "title": "React"
          },
          "locale": "zh-CN"
        },
        "title": "react"
      },
      {
        "path": "/zh-CN/three",
        "component": require('/Users/lianyafeng/Desktop/学习demo/dumi/myapp/src/three.md').default,
        "exact": true,
        "meta": {
          "filePath": "src/three.md",
          "updatedTime": 1623206712854,
          "slugs": [
            {
              "depth": 1,
              "value": "three",
              "heading": "three"
            },
            {
              "depth": 2,
              "value": "创建一个场景",
              "heading": "创建一个场景"
            },
            {
              "depth": 2,
              "value": "在 threejs 中定义一个点",
              "heading": "在-threejs-中定义一个点"
            },
            {
              "depth": 2,
              "value": "绘制一个坐标系",
              "heading": "绘制一个坐标系"
            },
            {
              "depth": 2,
              "value": "性能监视器 Stats",
              "heading": "性能监视器-stats"
            },
            {
              "depth": 2,
              "value": "动画引擎 Tween",
              "heading": "动画引擎-tween"
            },
            {
              "depth": 2,
              "value": "光源 Light",
              "heading": "光源-light"
            },
            {
              "depth": 3,
              "value": "光源基类",
              "heading": "光源基类"
            },
            {
              "depth": 3,
              "value": "派生光源",
              "heading": "派生光源"
            }
          ],
          "title": "three",
          "nav": {
            "path": "/zh-CN/three",
            "title": "Three"
          },
          "locale": "zh-CN"
        },
        "title": "three"
      },
      {
        "path": "/zh-CN/ts",
        "component": require('/Users/lianyafeng/Desktop/学习demo/dumi/myapp/src/ts.md').default,
        "exact": true,
        "meta": {
          "filePath": "src/ts.md",
          "updatedTime": 1627101538394,
          "slugs": [
            {
              "depth": 1,
              "value": "TypeScript",
              "heading": "typescript"
            },
            {
              "depth": 2,
              "value": "什么是TyprScript",
              "heading": "什么是typrscript"
            },
            {
              "depth": 2,
              "value": "tsc 命令",
              "heading": "tsc-命令"
            },
            {
              "depth": 2,
              "value": "类型批注",
              "heading": "类型批注"
            },
            {
              "depth": 2,
              "value": "interface",
              "heading": "interface"
            },
            {
              "depth": 2,
              "value": "lambda函数表达式",
              "heading": "lambda函数表达式"
            },
            {
              "depth": 2,
              "value": "class类",
              "heading": "class类"
            },
            {
              "depth": 2,
              "value": "继承",
              "heading": "继承"
            },
            {
              "depth": 2,
              "value": "any 类型",
              "heading": "any-类型"
            },
            {
              "depth": 2,
              "value": "null undefined",
              "heading": "null-undefined"
            },
            {
              "depth": 2,
              "value": "naver 类型",
              "heading": "naver-类型"
            },
            {
              "depth": 2,
              "value": "变量声明",
              "heading": "变量声明"
            },
            {
              "depth": 2,
              "value": "类型推断",
              "heading": "类型推断"
            },
            {
              "depth": 2,
              "value": "变量作用域",
              "heading": "变量作用域"
            },
            {
              "depth": 2,
              "value": "tsconfig.json 的作用",
              "heading": "tsconfigjson-的作用"
            },
            {
              "depth": 2,
              "value": "如何配置typescript编译器",
              "heading": "如何配置typescript编译器"
            }
          ],
          "title": "TypeScript",
          "nav": {
            "path": "/zh-CN/ts",
            "title": "Ts"
          },
          "locale": "zh-CN"
        },
        "title": "TypeScript"
      },
      {
        "path": "/zh-CN/vue",
        "component": require('/Users/lianyafeng/Desktop/学习demo/dumi/myapp/src/vue.md').default,
        "exact": true,
        "meta": {
          "filePath": "src/vue.md",
          "updatedTime": 1627039504381,
          "slugs": [
            {
              "depth": 1,
              "value": "vue",
              "heading": "vue"
            },
            {
              "depth": 2,
              "value": "数据响应式",
              "heading": "数据响应式"
            },
            {
              "depth": 2,
              "value": "vue nextTick",
              "heading": "vue-nexttick"
            },
            {
              "depth": 2,
              "value": "vue 生命周期的作用是什么",
              "heading": "vue-生命周期的作用是什么"
            },
            {
              "depth": 2,
              "value": "第一次页面加载会触发哪几个钩子",
              "heading": "第一次页面加载会触发哪几个钩子"
            },
            {
              "depth": 2,
              "value": "简述每个周期具体适合哪些场景",
              "heading": "简述每个周期具体适合哪些场景"
            },
            {
              "depth": 2,
              "value": "created 和 mounted 的区别",
              "heading": "created-和-mounted-的区别"
            },
            {
              "depth": 2,
              "value": "vue 获取数据在哪个周期函数",
              "heading": "vue-获取数据在哪个周期函数"
            },
            {
              "depth": 2,
              "value": "mvvm",
              "heading": "mvvm"
            },
            {
              "depth": 2,
              "value": "vue-router 是什么?它有哪些组件",
              "heading": "vue-router-是什么它有哪些组件"
            },
            {
              "depth": 2,
              "value": "active-class 是哪个组件的属性？",
              "heading": "active-class-是哪个组件的属性？"
            },
            {
              "depth": 2,
              "value": "怎么定义 vue-router 的动态路由? 怎么获取传过来的值",
              "heading": "怎么定义-vue-router-的动态路由-怎么获取传过来的值"
            },
            {
              "depth": 2,
              "value": "vue-router 有哪几种导航钩子?",
              "heading": "vue-router-有哪几种导航钩子"
            },
            {
              "depth": 2,
              "value": "$route 和 $router 的区别",
              "heading": "route-和-router-的区别"
            },
            {
              "depth": 2,
              "value": "vue-router 响应路由参数的变化",
              "heading": "vue-router-响应路由参数的变化"
            },
            {
              "depth": 2,
              "value": "vue-router 传参",
              "heading": "vue-router-传参"
            },
            {
              "depth": 2,
              "value": "vue 优点",
              "heading": "vue-优点"
            },
            {
              "depth": 2,
              "value": "vue 父组件向子组件传递数据？",
              "heading": "vue-父组件向子组件传递数据？"
            },
            {
              "depth": 2,
              "value": "子组件像父组件传递事件",
              "heading": "子组件像父组件传递事件"
            },
            {
              "depth": 2,
              "value": "如何让 CSS 只在当前组件中起作用",
              "heading": "如何让-css-只在当前组件中起作用"
            },
            {
              "depth": 2,
              "value": "<keep-alive></keep-alive>的作用是什么?",
              "heading": "keep-alivekeep-alive的作用是什么"
            },
            {
              "depth": 2,
              "value": "如何获取 dom",
              "heading": "如何获取-dom"
            },
            {
              "depth": 2,
              "value": "vue-loader 是什么？使用它的途径有哪些？",
              "heading": "vue-loader-是什么？使用它的途径有哪些？"
            },
            {
              "depth": 2,
              "value": "为什么使用 key",
              "heading": "为什么使用-key"
            },
            {
              "depth": 2,
              "value": "axios 解决跨域",
              "heading": "axios-解决跨域"
            },
            {
              "depth": 2,
              "value": "vue-cli 项目中 src 目录每个文件夹和文件的用法",
              "heading": "vue-cli-项目中-src-目录每个文件夹和文件的用法"
            },
            {
              "depth": 2,
              "value": "分别简述 computed 和 watch 的使用场景",
              "heading": "分别简述-computed-和-watch-的使用场景"
            },
            {
              "depth": 2,
              "value": "v-on 可以监听多个方法吗",
              "heading": "v-on-可以监听多个方法吗"
            },
            {
              "depth": 2,
              "value": "vue 组件中 data 为什么必须是一个函数",
              "heading": "vue-组件中-data-为什么必须是一个函数"
            },
            {
              "depth": 2,
              "value": "vue 事件对象的使用",
              "heading": "vue-事件对象的使用"
            },
            {
              "depth": 2,
              "value": "单页面应用和多页面应用区别及优缺点",
              "heading": "单页面应用和多页面应用区别及优缺点"
            },
            {
              "depth": 2,
              "value": "assets 和 static 的区别",
              "heading": "assets-和-static-的区别"
            },
            {
              "depth": 2,
              "value": "列举常用的指令",
              "heading": "列举常用的指令"
            },
            {
              "depth": 2,
              "value": "vue 常用的修饰符",
              "heading": "vue-常用的修饰符"
            },
            {
              "depth": 2,
              "value": "数组更新检测",
              "heading": "数组更新检测"
            },
            {
              "depth": 2,
              "value": "Vue.set 视图更新",
              "heading": "vueset-视图更新"
            },
            {
              "depth": 2,
              "value": "自定义指令详解",
              "heading": "自定义指令详解"
            },
            {
              "depth": 2,
              "value": "vue 的两个核心点",
              "heading": "vue-的两个核心点"
            },
            {
              "depth": 2,
              "value": "vue 和 jQuery 的区别",
              "heading": "vue-和-jquery-的区别"
            },
            {
              "depth": 2,
              "value": "引进组件的步骤",
              "heading": "引进组件的步骤"
            },
            {
              "depth": 2,
              "value": "Vue-cli 打包命令是什么？打包后悔导致路径问题，应该在哪里修改",
              "heading": "vue-cli-打包命令是什么？打包后悔导致路径问题，应该在哪里修改"
            },
            {
              "depth": 2,
              "value": "跨组件双向数据绑定",
              "heading": "跨组件双向数据绑定"
            },
            {
              "depth": 2,
              "value": "delete 和 Vue.delete 删除数组的区别",
              "heading": "delete-和-vuedelete-删除数组的区别"
            },
            {
              "depth": 2,
              "value": "SPA 首屏加载慢如何解决",
              "heading": "spa-首屏加载慢如何解决"
            },
            {
              "depth": 2,
              "value": "Vue-router 跳转和 location.href 有什么区别",
              "heading": "vue-router-跳转和-locationhref-有什么区别"
            },
            {
              "depth": 2,
              "value": "你们 vue 项目是打包了一个 js 文件，一个 css 文件，还是有多个文件？",
              "heading": "你们-vue-项目是打包了一个-js-文件，一个-css-文件，还是有多个文件？"
            },
            {
              "depth": 2,
              "value": "vue 遇到的坑，如何解决的？",
              "heading": "vue-遇到的坑，如何解决的？"
            },
            {
              "depth": 2,
              "value": "Vue 里面 router-link 在电脑上有用，在安卓上没反应怎么解决？",
              "heading": "vue-里面-router-link-在电脑上有用，在安卓上没反应怎么解决？"
            },
            {
              "depth": 2,
              "value": "Vue2 中注册在 router-link 上事件无效解决方法",
              "heading": "vue2-中注册在-router-link-上事件无效解决方法"
            },
            {
              "depth": 2,
              "value": "RouterLink 在 IE 和 Firefox 中不起作用（路由不跳转）的问题",
              "heading": "routerlink-在-ie-和-firefox-中不起作用（路由不跳转）的问题"
            },
            {
              "depth": 2,
              "value": "axios 的特点有哪些",
              "heading": "axios-的特点有哪些"
            },
            {
              "depth": 2,
              "value": "请说下封装 vue 组件的过程？",
              "heading": "请说下封装-vue-组件的过程？"
            },
            {
              "depth": 2,
              "value": "vue mock 数据",
              "heading": "vue-mock-数据"
            },
            {
              "depth": 2,
              "value": "vue 封装通用组件",
              "heading": "vue-封装通用组件"
            },
            {
              "depth": 2,
              "value": "vue 初始化页面闪动问题",
              "heading": "vue-初始化页面闪动问题"
            },
            {
              "depth": 2,
              "value": "vue 禁止弹窗后的屏幕滚动",
              "heading": "vue-禁止弹窗后的屏幕滚动"
            },
            {
              "depth": 2,
              "value": "vue 更新数组时触发视图更新的方法",
              "heading": "vue-更新数组时触发视图更新的方法"
            },
            {
              "depth": 3,
              "value": "1.",
              "heading": "1"
            },
            {
              "depth": 3,
              "value": "2.当需要对象合并的时候需要用到 lodash _.merge(对象 1，对象 2)",
              "heading": "2当需要对象合并的时候需要用到-lodash-_merge对象-1，对象-2"
            },
            {
              "depth": 3,
              "value": "3.项目优化策略",
              "heading": "3项目优化策略"
            },
            {
              "depth": 1,
              "value": "vuex",
              "heading": "vuex"
            },
            {
              "depth": 2,
              "value": "使用 vuex 的目的",
              "heading": "使用-vuex-的目的"
            },
            {
              "depth": 2,
              "value": "state",
              "heading": "state"
            },
            {
              "depth": 2,
              "value": "getter",
              "heading": "getter"
            },
            {
              "depth": 2,
              "value": "mutation",
              "heading": "mutation"
            },
            {
              "depth": 2,
              "value": "action",
              "heading": "action"
            },
            {
              "depth": 2,
              "value": "module",
              "heading": "module"
            },
            {
              "depth": 2,
              "value": "provide 和 inject",
              "heading": "provide-和-inject"
            },
            {
              "depth": 2,
              "value": "vue.observable()",
              "heading": "vueobservable"
            },
            {
              "depth": 2,
              "value": "vue3",
              "heading": "vue3"
            },
            {
              "depth": 2,
              "value": "Ajv",
              "heading": "ajv"
            },
            {
              "depth": 2,
              "value": "在不实用proxy的前提下 实现defineProperty可以新增数据",
              "heading": "在不实用proxy的前提下-实现defineproperty可以新增数据"
            }
          ],
          "title": "vue",
          "nav": {
            "path": "/zh-CN/vue",
            "title": "Vue"
          },
          "locale": "zh-CN"
        },
        "title": "vue"
      },
      {
        "path": "/zh-CN/vue学习文档",
        "component": require('/Users/lianyafeng/Desktop/学习demo/dumi/myapp/src/vue学习文档.md').default,
        "exact": true,
        "meta": {
          "filePath": "src/vue学习文档.md",
          "updatedTime": 1622039411703,
          "slugs": [
            {
              "depth": 3,
              "value": "1.v-cloak 闪动",
              "heading": "1v-cloak-闪动"
            },
            {
              "depth": 3,
              "value": "2.v-text 无闪动",
              "heading": "2v-text-无闪动"
            },
            {
              "depth": 3,
              "value": "3.v-html 插入html",
              "heading": "3v-html-插入html"
            },
            {
              "depth": 3,
              "value": "4.v-pre 显示原始信息 跳过编译过程",
              "heading": "4v-pre-显示原始信息-跳过编译过程"
            },
            {
              "depth": 3,
              "value": "5.数据响应式",
              "heading": "5数据响应式"
            },
            {
              "depth": 3,
              "value": "6.v-once 使页面上的内容只编译一次",
              "heading": "6v-once-使页面上的内容只编译一次"
            },
            {
              "depth": 3,
              "value": "7.双向数据绑定",
              "heading": "7双向数据绑定"
            },
            {
              "depth": 3,
              "value": "8.MVVM设计思想",
              "heading": "8mvvm设计思想"
            },
            {
              "depth": 3,
              "value": "9.事件绑定",
              "heading": "9事件绑定"
            },
            {
              "depth": 4,
              "value": "v-on",
              "heading": "v-on"
            },
            {
              "depth": 3,
              "value": "10.样式绑定",
              "heading": "10样式绑定"
            },
            {
              "depth": 3,
              "value": "11.v-for",
              "heading": "11v-for"
            },
            {
              "depth": 3,
              "value": "12.@click.prevent 阻止事件的默认行为",
              "heading": "12clickprevent-阻止事件的默认行为"
            },
            {
              "depth": 3,
              "value": "13.让select标签多选",
              "heading": "13让select标签多选"
            },
            {
              "depth": 3,
              "value": "14.v-model.number 将文本框的字符串转换成数值 可以直接运算",
              "heading": "14v-modelnumber-将文本框的字符串转换成数值-可以直接运算"
            },
            {
              "depth": 3,
              "value": "15. v-model.lazy",
              "heading": "15-v-modellazy"
            },
            {
              "depth": 3,
              "value": "16自定义指令",
              "heading": "16自定义指令"
            },
            {
              "depth": 3,
              "value": "17.带参数的自定义指令",
              "heading": "17带参数的自定义指令"
            },
            {
              "depth": 3,
              "value": "18.局部指令",
              "heading": "18局部指令"
            },
            {
              "depth": 3,
              "value": "19.计算属性",
              "heading": "19计算属性"
            },
            {
              "depth": 3,
              "value": "20.侦听器",
              "heading": "20侦听器"
            },
            {
              "depth": 3,
              "value": "21.过滤器",
              "heading": "21过滤器"
            },
            {
              "depth": 3,
              "value": "22.生命周期",
              "heading": "22生命周期"
            },
            {
              "depth": 3,
              "value": "22.vue的数组",
              "heading": "22vue的数组"
            },
            {
              "depth": 3,
              "value": "23.动态处理响应式数据",
              "heading": "23动态处理响应式数据"
            },
            {
              "depth": 3,
              "value": "24.filter过滤器",
              "heading": "24filter过滤器"
            },
            {
              "depth": 3,
              "value": "25.组件注册",
              "heading": "25组件注册"
            },
            {
              "depth": 3,
              "value": "26.组件间数据交互",
              "heading": "26组件间数据交互"
            },
            {
              "depth": 3,
              "value": "27.非父子组件间传值",
              "heading": "27非父子组件间传值"
            },
            {
              "depth": 3,
              "value": "28.组件插槽基本用法",
              "heading": "28组件插槽基本用法"
            },
            {
              "depth": 3,
              "value": "29.作用域插槽",
              "heading": "29作用域插槽"
            },
            {
              "depth": 3,
              "value": "30.blur失去焦点时触发事件",
              "heading": "30blur失去焦点时触发事件"
            },
            {
              "depth": 3,
              "value": "31.异步调用",
              "heading": "31异步调用"
            },
            {
              "depth": 3,
              "value": "31.Promise概述（处理回调函数嵌套变为线性",
              "heading": "31promise概述（处理回调函数嵌套变为线性"
            },
            {
              "depth": 3,
              "value": "32.Promise 基本用法",
              "heading": "32promise-基本用法"
            },
            {
              "depth": 3,
              "value": "33.promise常用的api",
              "heading": "33promise常用的api"
            },
            {
              "depth": 3,
              "value": "34.Promise的对象方法",
              "heading": "34promise的对象方法"
            },
            {
              "depth": 3,
              "value": "35.接口调用fetch用法",
              "heading": "35接口调用fetch用法"
            },
            {
              "depth": 3,
              "value": "36.axios的基本特性",
              "heading": "36axios的基本特性"
            },
            {
              "depth": 3,
              "value": "37.axios的参数传递",
              "heading": "37axios的参数传递"
            },
            {
              "depth": 3,
              "value": "38.axios的响应结果",
              "heading": "38axios的响应结果"
            },
            {
              "depth": 3,
              "value": "39.axios 拦截器",
              "heading": "39axios-拦截器"
            },
            {
              "depth": 3,
              "value": "40.async/await的基本用法",
              "heading": "40asyncawait的基本用法"
            },
            {
              "depth": 3,
              "value": "41.async/await的基本用法",
              "heading": "41asyncawait的基本用法"
            },
            {
              "depth": 3,
              "value": "42.路由",
              "heading": "42路由"
            },
            {
              "depth": 3,
              "value": "43.vue router",
              "heading": "43vue-router"
            },
            {
              "depth": 3,
              "value": "44.模块化",
              "heading": "44模块化"
            },
            {
              "depth": 3,
              "value": "45.commonJS规范",
              "heading": "45commonjs规范"
            },
            {
              "depth": 3,
              "value": "46.ES6模块化规范标准",
              "heading": "46es6模块化规范标准"
            },
            {
              "depth": 3,
              "value": "47 babel",
              "heading": "47-babel"
            },
            {
              "depth": 3,
              "value": "48.webpack",
              "heading": "48webpack"
            },
            {
              "depth": 3,
              "value": "49.webpack 配置",
              "heading": "49webpack-配置"
            },
            {
              "depth": 3,
              "value": "50.webpack自动打包功能",
              "heading": "50webpack自动打包功能"
            },
            {
              "depth": 3,
              "value": "51.webpack配置插件",
              "heading": "51webpack配置插件"
            },
            {
              "depth": 3,
              "value": "52.webpack 打包完成后自动打开浏览器显示项目",
              "heading": "52webpack-打包完成后自动打开浏览器显示项目"
            },
            {
              "depth": 3,
              "value": "53.webpack loader 加载器",
              "heading": "53webpack-loader-加载器"
            },
            {
              "depth": 3,
              "value": "54.处理css浏览器兼容性问题",
              "heading": "54处理css浏览器兼容性问题"
            },
            {
              "depth": 3,
              "value": "55.加载图片和文件字体",
              "heading": "55加载图片和文件字体"
            },
            {
              "depth": 3,
              "value": "56.打包处理js文件中的高级语法",
              "heading": "56打包处理js文件中的高级语法"
            },
            {
              "depth": 3,
              "value": "57.webpack 配置 vue组件的加载器",
              "heading": "57webpack-配置-vue组件的加载器"
            },
            {
              "depth": 3,
              "value": "58. 在webpack项目中使用vue",
              "heading": "58-在webpack项目中使用vue"
            },
            {
              "depth": 3,
              "value": "59.打包发布",
              "heading": "59打包发布"
            },
            {
              "depth": 3,
              "value": "60.git 创建分枝",
              "heading": "60git-创建分枝"
            },
            {
              "depth": 3,
              "value": "61. vue路由导航守卫",
              "heading": "61-vue路由导航守卫"
            },
            {
              "depth": 3,
              "value": "62.vue为开发模式与发布模式指定不同的打包入口",
              "heading": "62vue为开发模式与发布模式指定不同的打包入口"
            },
            {
              "depth": 3,
              "value": "63.configureWebpack 和 chainWebpack",
              "heading": "63configurewebpack-和-chainwebpack"
            },
            {
              "depth": 3,
              "value": "64.vue nextTick",
              "heading": "64vue-nexttick"
            }
          ],
          "title": "1.v-cloak 闪动",
          "nav": {
            "path": "/zh-CN/vue学习文档",
            "title": "Vue学习文档"
          },
          "locale": "zh-CN"
        },
        "title": "1.v-cloak 闪动"
      },
      {
        "path": "/zh-CN/websocket",
        "component": require('/Users/lianyafeng/Desktop/学习demo/dumi/myapp/src/websocket.md').default,
        "exact": true,
        "meta": {
          "filePath": "src/websocket.md",
          "updatedTime": 1627058172922,
          "slugs": [],
          "title": "Websocket",
          "nav": {
            "path": "/zh-CN/websocket",
            "title": "Websocket"
          },
          "locale": "zh-CN"
        },
        "title": "Websocket"
      },
      {
        "path": "/zh-CN/工程化",
        "component": require('/Users/lianyafeng/Desktop/学习demo/dumi/myapp/src/工程化.md').default,
        "exact": true,
        "meta": {
          "filePath": "src/工程化.md",
          "updatedTime": 1627020224723,
          "slugs": [
            {
              "depth": 1,
              "value": "工程化",
              "heading": "工程化"
            },
            {
              "depth": 2,
              "value": "工厂模式",
              "heading": "工厂模式"
            },
            {
              "depth": 2,
              "value": "BRD 和 SRS",
              "heading": "brd-和-srs"
            },
            {
              "depth": 2,
              "value": "软件开发的五个阶段",
              "heading": "软件开发的五个阶段"
            },
            {
              "depth": 2,
              "value": "yarn 与 npm的区别",
              "heading": "yarn-与-npm的区别"
            },
            {
              "depth": 2,
              "value": "git工作流",
              "heading": "git工作流"
            },
            {
              "depth": 2,
              "value": "webpack的作用",
              "heading": "webpack的作用"
            },
            {
              "depth": 2,
              "value": "webpack 与grunt、gulp的不同",
              "heading": "webpack-与grunt、gulp的不同"
            },
            {
              "depth": 2,
              "value": "常见的loader",
              "heading": "常见的loader"
            },
            {
              "depth": 2,
              "value": "常见的plugin",
              "heading": "常见的plugin"
            },
            {
              "depth": 2,
              "value": "loader和plugin的不同",
              "heading": "loader和plugin的不同"
            },
            {
              "depth": 2,
              "value": "webpack 的构建流程",
              "heading": "webpack-的构建流程"
            }
          ],
          "title": "工程化",
          "nav": {
            "path": "/zh-CN/工程化",
            "title": "工程化"
          },
          "locale": "zh-CN"
        },
        "title": "工程化"
      },
      {
        "path": "/zh-CN/浏览器",
        "component": require('/Users/lianyafeng/Desktop/学习demo/dumi/myapp/src/浏览器.md').default,
        "exact": true,
        "meta": {
          "filePath": "src/浏览器.md",
          "updatedTime": 1627135426468,
          "slugs": [
            {
              "depth": 2,
              "value": "网络协议",
              "heading": "网络协议"
            },
            {
              "depth": 2,
              "value": "http",
              "heading": "http"
            },
            {
              "depth": 2,
              "value": "https",
              "heading": "https"
            },
            {
              "depth": 2,
              "value": "UDP",
              "heading": "udp"
            },
            {
              "depth": 2,
              "value": "TCP",
              "heading": "tcp"
            },
            {
              "depth": 2,
              "value": "DNS",
              "heading": "dns"
            },
            {
              "depth": 4,
              "value": "在地址栏里输入一个 URL,到这个页面呈现出来，中间会发生什么？",
              "heading": "在地址栏里输入一个-url到这个页面呈现出来，中间会发生什么？"
            },
            {
              "depth": 2,
              "value": "websocket",
              "heading": "websocket"
            },
            {
              "depth": 3,
              "value": "后端 node",
              "heading": "后端-node"
            },
            {
              "depth": 4,
              "value": "安装包",
              "heading": "安装包"
            },
            {
              "depth": 4,
              "value": "创建对象",
              "heading": "创建对象"
            },
            {
              "depth": 4,
              "value": "监听事件",
              "heading": "监听事件"
            },
            {
              "depth": 4,
              "value": "发送数据",
              "heading": "发送数据"
            },
            {
              "depth": 3,
              "value": "前端",
              "heading": "前端"
            },
            {
              "depth": 4,
              "value": "创建对象",
              "heading": "创建对象-1"
            },
            {
              "depth": 4,
              "value": "监听事件",
              "heading": "监听事件-1"
            },
            {
              "depth": 4,
              "value": "发送数据",
              "heading": "发送数据-1"
            },
            {
              "depth": 2,
              "value": "性能优化",
              "heading": "性能优化"
            },
            {
              "depth": 2,
              "value": "如何优化性能",
              "heading": "如何优化性能"
            },
            {
              "depth": 3,
              "value": "浏览器缓存策略",
              "heading": "浏览器缓存策略"
            },
            {
              "depth": 2,
              "value": "静态资源的加载",
              "heading": "静态资源的加载"
            },
            {
              "depth": 3,
              "value": "cdn 静态资源服务器 缓存",
              "heading": "cdn-静态资源服务器-缓存"
            },
            {
              "depth": 2,
              "value": "html和dom有什么不同",
              "heading": "html和dom有什么不同"
            }
          ],
          "title": "网络协议",
          "nav": {
            "path": "/zh-CN/浏览器",
            "title": "浏览器"
          },
          "locale": "zh-CN"
        },
        "title": "网络协议"
      },
      {
        "path": "/zh-CN/电商管理后台 api 接口文档",
        "component": require('/Users/lianyafeng/Desktop/学习demo/dumi/myapp/src/电商管理后台 API 接口文档.md').default,
        "exact": true,
        "meta": {
          "filePath": "src/电商管理后台 API 接口文档.md",
          "updatedTime": 1621144243884,
          "slugs": [
            {
              "depth": 1,
              "value": "1. 电商管理后台 API 接口文档",
              "heading": "1-电商管理后台-api-接口文档"
            },
            {
              "depth": 2,
              "value": "1.1. API V1 接口说明",
              "heading": "11-api-v1-接口说明"
            },
            {
              "depth": 3,
              "value": "1.1.1. 支持的请求方法",
              "heading": "111-支持的请求方法"
            },
            {
              "depth": 3,
              "value": "1.1.2. 通用返回状态说明",
              "heading": "112-通用返回状态说明"
            },
            {
              "depth": 2,
              "value": "1.2. 登录",
              "heading": "12-登录"
            },
            {
              "depth": 3,
              "value": "1.2.1. 登录验证接口",
              "heading": "121-登录验证接口"
            },
            {
              "depth": 2,
              "value": "1.3. 用户管理",
              "heading": "13-用户管理"
            },
            {
              "depth": 3,
              "value": "1.3.1. 用户数据列表",
              "heading": "131-用户数据列表"
            },
            {
              "depth": 3,
              "value": "1.3.2. 添加用户",
              "heading": "132-添加用户"
            },
            {
              "depth": 3,
              "value": "1.3.3. 修改用户状态",
              "heading": "133-修改用户状态"
            },
            {
              "depth": 3,
              "value": "1.3.4. 根据 ID 查询用户信息",
              "heading": "134-根据-id-查询用户信息"
            },
            {
              "depth": 3,
              "value": "1.3.5. 编辑用户提交",
              "heading": "135-编辑用户提交"
            },
            {
              "depth": 3,
              "value": "1.3.6. 删除单个用户",
              "heading": "136-删除单个用户"
            },
            {
              "depth": 3,
              "value": "1.3.7. 分配用户角色",
              "heading": "137-分配用户角色"
            },
            {
              "depth": 2,
              "value": "1.4. 权限管理",
              "heading": "14-权限管理"
            },
            {
              "depth": 3,
              "value": "1.4.1. 所有权限列表",
              "heading": "141-所有权限列表"
            },
            {
              "depth": 3,
              "value": "1.4.2. 左侧菜单权限",
              "heading": "142-左侧菜单权限"
            },
            {
              "depth": 2,
              "value": "1.5. 角色管理",
              "heading": "15-角色管理"
            },
            {
              "depth": 3,
              "value": "1.5.1. 角色列表",
              "heading": "151-角色列表"
            },
            {
              "depth": 3,
              "value": "1.5.2. 添加角色",
              "heading": "152-添加角色"
            },
            {
              "depth": 3,
              "value": "1.5.3. 根据 ID 查询角色",
              "heading": "153-根据-id-查询角色"
            },
            {
              "depth": 3,
              "value": "1.5.4. 编辑提交角色",
              "heading": "154-编辑提交角色"
            },
            {
              "depth": 3,
              "value": "1.5.5. 删除角色",
              "heading": "155-删除角色"
            },
            {
              "depth": 3,
              "value": "1.5.6. 角色授权",
              "heading": "156-角色授权"
            },
            {
              "depth": 3,
              "value": "1.5.7. 删除角色指定权限",
              "heading": "157-删除角色指定权限"
            },
            {
              "depth": 2,
              "value": "1.6. 商品分类管理",
              "heading": "16-商品分类管理"
            },
            {
              "depth": 3,
              "value": "1.6.1. 商品分类数据列表",
              "heading": "161-商品分类数据列表"
            },
            {
              "depth": 3,
              "value": "1.6.2. 添加分类",
              "heading": "162-添加分类"
            },
            {
              "depth": 3,
              "value": "1.6.3. 根据 id 查询分类",
              "heading": "163-根据-id-查询分类"
            },
            {
              "depth": 3,
              "value": "1.6.4. 编辑提交分类",
              "heading": "164-编辑提交分类"
            },
            {
              "depth": 3,
              "value": "1.6.5. 删除分类",
              "heading": "165-删除分类"
            },
            {
              "depth": 2,
              "value": "1.7. 分类参数管理",
              "heading": "17-分类参数管理"
            },
            {
              "depth": 3,
              "value": "1.7.1. 参数列表",
              "heading": "171-参数列表"
            },
            {
              "depth": 3,
              "value": "1.7.2. 添加动态参数或者静态属性",
              "heading": "172-添加动态参数或者静态属性"
            },
            {
              "depth": 3,
              "value": "1.7.3. 删除参数",
              "heading": "173-删除参数"
            },
            {
              "depth": 3,
              "value": "1.7.4. 根据 ID 查询参数",
              "heading": "174-根据-id-查询参数"
            },
            {
              "depth": 3,
              "value": "1.7.5. 编辑提交参数",
              "heading": "175-编辑提交参数"
            },
            {
              "depth": 2,
              "value": "1.8. 商品管理",
              "heading": "18-商品管理"
            },
            {
              "depth": 3,
              "value": "1.8.1. 商品列表数据",
              "heading": "181-商品列表数据"
            },
            {
              "depth": 3,
              "value": "1.8.2. 添加商品",
              "heading": "182-添加商品"
            },
            {
              "depth": 3,
              "value": "1.8.3. 根据 ID 查询商品",
              "heading": "183-根据-id-查询商品"
            },
            {
              "depth": 3,
              "value": "1.8.4. 编辑提交商品",
              "heading": "184-编辑提交商品"
            },
            {
              "depth": 3,
              "value": "1.8.5. 删除商品",
              "heading": "185-删除商品"
            },
            {
              "depth": 2,
              "value": "1.9. 图片上传",
              "heading": "19-图片上传"
            },
            {
              "depth": 2,
              "value": "1.10. 订单管理",
              "heading": "110-订单管理"
            },
            {
              "depth": 3,
              "value": "1.10.1. 订单数据列表",
              "heading": "1101-订单数据列表"
            },
            {
              "depth": 3,
              "value": "1.10.2. 修改订单状态",
              "heading": "1102-修改订单状态"
            },
            {
              "depth": 3,
              "value": "1.10.3. 查看订单详情",
              "heading": "1103-查看订单详情"
            },
            {
              "depth": 3,
              "value": "1.10.4. 修改地址",
              "heading": "1104-修改地址"
            },
            {
              "depth": 3,
              "value": "1.10.5. 查看物流信息",
              "heading": "1105-查看物流信息"
            },
            {
              "depth": 2,
              "value": "1.11. 数据统计",
              "heading": "111-数据统计"
            },
            {
              "depth": 3,
              "value": "1.11.1.  基于时间统计的折线图",
              "heading": "1111--基于时间统计的折线图"
            }
          ],
          "title": "1. 电商管理后台 API 接口文档",
          "nav": {
            "path": "/zh-CN/电商管理后台 api 接口文档",
            "title": "电商管理后台 api 接口文档"
          },
          "locale": "zh-CN"
        },
        "title": "1. 电商管理后台 API 接口文档"
      },
      {
        "path": "/zh-CN/components/foo",
        "component": require('/Users/lianyafeng/Desktop/学习demo/dumi/myapp/src/Foo/index.md').default,
        "exact": true,
        "meta": {
          "filePath": "src/Foo/index.md",
          "updatedTime": 1621160862211,
          "componentName": "Foo",
          "nav": {
            "title": "Components",
            "path": "/zh-CN/components"
          },
          "slugs": [
            {
              "depth": 2,
              "value": "Foo",
              "heading": "foo"
            }
          ],
          "title": "Foo",
          "group": {
            "path": "/zh-CN/components/foo",
            "title": "Foo"
          },
          "locale": "zh-CN"
        },
        "title": "Foo"
      },
      {
        "path": "/components",
        "meta": {},
        "exact": true,
        "redirect": "/components/foo"
      },
      {
        "path": "/zh-CN/components",
        "meta": {},
        "exact": true,
        "redirect": "/zh-CN/components/foo"
      }
    ],
    "title": "连亚锋个人博客",
    "component": (props) => props.children
  }
];

  // allow user to extend routes
  plugin.applyPlugins({
    key: 'patchRoutes',
    type: ApplyPluginsType.event,
    args: { routes },
  });

  return routes;
}
