// @ts-nocheck
import { Plugin } from '/Users/lianyafeng/Desktop/学习demo/dumi/myapp/node_modules/@umijs/runtime';

const plugin = new Plugin({
  validKeys: ['modifyClientRenderOpts','patchRoutes','rootContainer','render','onRouteChange',],
});

export { plugin };
